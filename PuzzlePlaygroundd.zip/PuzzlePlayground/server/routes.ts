import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from 'zod';
import { 
  insertUserSchema, 
  insertAirdropSchema, 
  insertParticipantSchema, 
  insertTaskSchema, 
  insertTaskCompletionSchema 
} from '../shared/schema';

// Middleware for checking authentication
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  next();
};

// Middleware for checking admin role
const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  
  const user = await storage.getUser(req.session.userId);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin privileges required' });
  }
  
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'ok', time: new Date().toISOString() });
  });
  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ error: 'Username already taken' });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ error: 'Email already registered' });
      }
      
      const user = await storage.createUser(userData);
      
      // Auto login after registration
      req.session.userId = user.id;
      
      return res.status(201).json({ 
        id: user.id, 
        username: user.username, 
        email: user.email,
        walletAddress: user.walletAddress,
        role: user.role
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error('Registration error:', error);
      return res.status(500).json({ error: 'Failed to register user' });
    }
  });
  
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      
      req.session.userId = user.id;
      
      return res.json({ 
        id: user.id, 
        username: user.username, 
        email: user.email,
        walletAddress: user.walletAddress,
        role: user.role
      });
    } catch (error) {
      console.error('Login error:', error);
      return res.status(500).json({ error: 'Failed to login' });
    }
  });
  
  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ error: 'Failed to logout' });
      }
      res.clearCookie('connect.sid');
      return res.json({ message: 'Logged out successfully' });
    });
  });
  
  app.get('/api/auth/me', requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      return res.json({ 
        id: user.id, 
        username: user.username, 
        email: user.email,
        walletAddress: user.walletAddress,
        role: user.role
      });
    } catch (error) {
      console.error('Get current user error:', error);
      return res.status(500).json({ error: 'Failed to get user data' });
    }
  });
  
  // Airdrops routes
  app.get('/api/airdrops', async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;
      
      const airdrops = await storage.getAirdrops(offset, limit);
      return res.json(airdrops);
    } catch (error) {
      console.error('Get airdrops error:', error);
      return res.status(500).json({ error: 'Failed to fetch airdrops' });
    }
  });
  
  app.get('/api/airdrops/active', async (req, res) => {
    try {
      const activeAirdrops = await storage.getActiveAirdrops();
      return res.json(activeAirdrops);
    } catch (error) {
      console.error('Get active airdrops error:', error);
      return res.status(500).json({ error: 'Failed to fetch active airdrops' });
    }
  });
  
  app.get('/api/airdrops/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid airdrop ID' });
      }
      
      const airdrop = await storage.getAirdrop(id);
      if (!airdrop) {
        return res.status(404).json({ error: 'Airdrop not found' });
      }
      
      return res.json(airdrop);
    } catch (error) {
      console.error('Get airdrop error:', error);
      return res.status(500).json({ error: 'Failed to fetch airdrop' });
    }
  });
  
  app.post('/api/airdrops', requireAuth, async (req, res) => {
    try {
      const airdropData = insertAirdropSchema.parse(req.body);
      
      // Set the creator ID from the session
      airdropData.createdBy = req.session.userId!;
      
      const airdrop = await storage.createAirdrop(airdropData);
      return res.status(201).json(airdrop);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error('Create airdrop error:', error);
      return res.status(500).json({ error: 'Failed to create airdrop' });
    }
  });
  
  app.put('/api/airdrops/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid airdrop ID' });
      }
      
      const airdrop = await storage.getAirdrop(id);
      if (!airdrop) {
        return res.status(404).json({ error: 'Airdrop not found' });
      }
      
      // Check if user is authorized to update this airdrop
      if (airdrop.createdBy !== req.session.userId) {
        const user = await storage.getUser(req.session.userId!);
        if (!user || user.role !== 'admin') {
          return res.status(403).json({ error: 'Not authorized to update this airdrop' });
        }
      }
      
      const updatedAirdrop = await storage.updateAirdrop(id, req.body);
      return res.json(updatedAirdrop);
    } catch (error) {
      console.error('Update airdrop error:', error);
      return res.status(500).json({ error: 'Failed to update airdrop' });
    }
  });
  
  // Participants routes
  app.get('/api/airdrops/:airdropId/participants', async (req, res) => {
    try {
      const airdropId = parseInt(req.params.airdropId);
      if (isNaN(airdropId)) {
        return res.status(400).json({ error: 'Invalid airdrop ID' });
      }
      
      const participants = await storage.getParticipantsByAirdrop(airdropId);
      return res.json(participants);
    } catch (error) {
      console.error('Get participants error:', error);
      return res.status(500).json({ error: 'Failed to fetch participants' });
    }
  });
  
  app.post('/api/participants', requireAuth, async (req, res) => {
    try {
      const participantData = insertParticipantSchema.parse(req.body);
      
      // If user ID is not provided, use the authenticated user
      if (!participantData.userId) {
        participantData.userId = req.session.userId!;
      }
      
      // Check if user already registered for this airdrop
      const existingParticipants = await storage.getParticipantsByUser(participantData.userId);
      const alreadyRegistered = existingParticipants.some(p => p.airdropId === participantData.airdropId);
      
      if (alreadyRegistered) {
        return res.status(400).json({ error: 'Already registered for this airdrop' });
      }
      
      const participant = await storage.createParticipant(participantData);
      return res.status(201).json(participant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error('Create participant error:', error);
      return res.status(500).json({ error: 'Failed to register for airdrop' });
    }
  });
  
  app.put('/api/participants/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid participant ID' });
      }
      
      const participant = await storage.getParticipant(id);
      if (!participant) {
        return res.status(404).json({ error: 'Participant not found' });
      }
      
      // Check if user is authorized to update this participant
      const isAdmin = req.session.userId && (await storage.getUser(req.session.userId))?.role === 'admin';
      if (participant.userId !== req.session.userId && !isAdmin) {
        return res.status(403).json({ error: 'Not authorized to update this participant' });
      }
      
      const updatedParticipant = await storage.updateParticipant(id, req.body);
      return res.json(updatedParticipant);
    } catch (error) {
      console.error('Update participant error:', error);
      return res.status(500).json({ error: 'Failed to update participant' });
    }
  });
  
  // Tasks routes
  app.get('/api/airdrops/:airdropId/tasks', async (req, res) => {
    try {
      const airdropId = parseInt(req.params.airdropId);
      if (isNaN(airdropId)) {
        return res.status(400).json({ error: 'Invalid airdrop ID' });
      }
      
      const tasks = await storage.getTasksByAirdrop(airdropId);
      return res.json(tasks);
    } catch (error) {
      console.error('Get tasks error:', error);
      return res.status(500).json({ error: 'Failed to fetch tasks' });
    }
  });
  
  app.post('/api/tasks', requireAuth, async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      
      // Check if user is authorized to create tasks for this airdrop
      const airdrop = await storage.getAirdrop(taskData.airdropId);
      if (!airdrop) {
        return res.status(404).json({ error: 'Airdrop not found' });
      }
      
      const isAdmin = req.session.userId && (await storage.getUser(req.session.userId))?.role === 'admin';
      if (airdrop.createdBy !== req.session.userId && !isAdmin) {
        return res.status(403).json({ error: 'Not authorized to create tasks for this airdrop' });
      }
      
      const task = await storage.createTask(taskData);
      return res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error('Create task error:', error);
      return res.status(500).json({ error: 'Failed to create task' });
    }
  });
  
  // Task completions routes
  app.post('/api/task-completions', requireAuth, async (req, res) => {
    try {
      const completionData = insertTaskCompletionSchema.parse(req.body);
      
      // If user ID is not provided, use the authenticated user
      if (!completionData.userId) {
        completionData.userId = req.session.userId!;
      }
      
      // Check if the task exists
      const task = await storage.getTask(completionData.taskId);
      if (!task) {
        return res.status(404).json({ error: 'Task not found' });
      }
      
      // Check if user already completed this task
      const userCompletions = await storage.getTaskCompletionsByUser(completionData.userId);
      const alreadyCompleted = userCompletions.some(tc => tc.taskId === completionData.taskId);
      
      if (alreadyCompleted) {
        return res.status(400).json({ error: 'Task already completed' });
      }
      
      const taskCompletion = await storage.createTaskCompletion(completionData);
      return res.status(201).json(taskCompletion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error('Create task completion error:', error);
      return res.status(500).json({ error: 'Failed to submit task completion' });
    }
  });
  
  app.put('/api/task-completions/:id/verify', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid task completion ID' });
      }
      
      // Check if user is authorized to verify task completions
      const user = await storage.getUser(req.session.userId!);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ error: 'Not authorized to verify task completions' });
      }
      
      const taskCompletion = await storage.updateTaskCompletion(id, {
        status: 'completed',
        verifiedAt: new Date(),
        verifiedBy: user.id
      });
      
      return res.json(taskCompletion);
    } catch (error) {
      console.error('Verify task completion error:', error);
      return res.status(500).json({ error: 'Failed to verify task completion' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
