import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { 
  users, airdrops, participants, tasks, taskCompletions,
  type User, type InsertUser, 
  type Airdrop, type InsertAirdrop,
  type Participant, type InsertParticipant,
  type Task, type InsertTask,
  type TaskCompletion, type InsertTaskCompletion
} from "../shared/schema";
import { eq, and, lte, gte, isNull, or } from "drizzle-orm";

// Initialize the database client
const connectionString = process.env.DATABASE_URL || 
  `postgres://${process.env.PGUSER}:${process.env.PGPASSWORD}@${process.env.PGHOST}:${process.env.PGPORT}/${process.env.PGDATABASE}`;

const client = postgres(connectionString);
const db = drizzle(client);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Airdrop operations
  getAirdrop(id: number): Promise<Airdrop | undefined>;
  getAirdrops(offset?: number, limit?: number): Promise<Airdrop[]>;
  getAirdropsByStatus(status: string): Promise<Airdrop[]>;
  getActiveAirdrops(): Promise<Airdrop[]>;
  createAirdrop(airdrop: InsertAirdrop): Promise<Airdrop>;
  updateAirdrop(id: number, airdrop: Partial<Airdrop>): Promise<Airdrop | undefined>;
  
  // Participant operations
  getParticipant(id: number): Promise<Participant | undefined>;
  getParticipantsByAirdrop(airdropId: number): Promise<Participant[]>;
  getParticipantsByUser(userId: number): Promise<Participant[]>;
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  updateParticipant(id: number, participant: Partial<Participant>): Promise<Participant | undefined>;
  
  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  getTasksByAirdrop(airdropId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  
  // Task completion operations
  getTaskCompletion(id: number): Promise<TaskCompletion | undefined>;
  getTaskCompletionsByUser(userId: number): Promise<TaskCompletion[]>;
  getTaskCompletionsByTask(taskId: number): Promise<TaskCompletion[]>;
  createTaskCompletion(taskCompletion: InsertTaskCompletion): Promise<TaskCompletion>;
  updateTaskCompletion(id: number, taskCompletion: Partial<TaskCompletion>): Promise<TaskCompletion | undefined>;
}

export class DbStorage implements IStorage {
  constructor() {
    // Initialize will happen with drizzle migration
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUser(id: number, user: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set({...user, updatedAt: new Date()})
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Airdrop operations
  async getAirdrop(id: number): Promise<Airdrop | undefined> {
    const result = await db.select().from(airdrops).where(eq(airdrops.id, id));
    return result[0];
  }

  async getAirdrops(offset = 0, limit = 10): Promise<Airdrop[]> {
    return await db.select().from(airdrops).limit(limit).offset(offset);
  }

  async getAirdropsByStatus(status: string): Promise<Airdrop[]> {
    return await db.select().from(airdrops).where(eq(airdrops.status, status));
  }

  async getActiveAirdrops(): Promise<Airdrop[]> {
    const now = new Date();
    return await db.select()
      .from(airdrops)
      .where(
        and(
          eq(airdrops.status, 'active'),
          lte(airdrops.startDate, now),
          or(
            gte(airdrops.endDate, now),
            isNull(airdrops.endDate)
          )
        )
      );
  }

  async createAirdrop(airdrop: InsertAirdrop): Promise<Airdrop> {
    const result = await db.insert(airdrops).values(airdrop).returning();
    return result[0];
  }

  async updateAirdrop(id: number, airdrop: Partial<Airdrop>): Promise<Airdrop | undefined> {
    const result = await db.update(airdrops)
      .set({...airdrop, updatedAt: new Date()})
      .where(eq(airdrops.id, id))
      .returning();
    return result[0];
  }

  // Participant operations
  async getParticipant(id: number): Promise<Participant | undefined> {
    const result = await db.select().from(participants).where(eq(participants.id, id));
    return result[0];
  }

  async getParticipantsByAirdrop(airdropId: number): Promise<Participant[]> {
    return await db.select().from(participants).where(eq(participants.airdropId, airdropId));
  }

  async getParticipantsByUser(userId: number): Promise<Participant[]> {
    return await db.select().from(participants).where(eq(participants.userId, userId));
  }

  async createParticipant(participant: InsertParticipant): Promise<Participant> {
    const result = await db.insert(participants).values(participant).returning();
    return result[0];
  }

  async updateParticipant(id: number, participant: Partial<Participant>): Promise<Participant | undefined> {
    const result = await db.update(participants)
      .set({...participant, updatedAt: new Date()})
      .where(eq(participants.id, id))
      .returning();
    return result[0];
  }

  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id));
    return result[0];
  }

  async getTasksByAirdrop(airdropId: number): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.airdropId, airdropId));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const result = await db.insert(tasks).values(task).returning();
    return result[0];
  }

  async updateTask(id: number, task: Partial<Task>): Promise<Task | undefined> {
    const result = await db.update(tasks)
      .set({...task, updatedAt: new Date()})
      .where(eq(tasks.id, id))
      .returning();
    return result[0];
  }

  // Task completion operations
  async getTaskCompletion(id: number): Promise<TaskCompletion | undefined> {
    const result = await db.select().from(taskCompletions).where(eq(taskCompletions.id, id));
    return result[0];
  }

  async getTaskCompletionsByUser(userId: number): Promise<TaskCompletion[]> {
    return await db.select().from(taskCompletions).where(eq(taskCompletions.userId, userId));
  }

  async getTaskCompletionsByTask(taskId: number): Promise<TaskCompletion[]> {
    return await db.select().from(taskCompletions).where(eq(taskCompletions.taskId, taskId));
  }

  async createTaskCompletion(taskCompletion: InsertTaskCompletion): Promise<TaskCompletion> {
    const result = await db.insert(taskCompletions).values(taskCompletion).returning();
    return result[0];
  }

  async updateTaskCompletion(id: number, taskCompletion: Partial<TaskCompletion>): Promise<TaskCompletion | undefined> {
    const result = await db.update(taskCompletions)
      .set({...taskCompletion, updatedAt: new Date()})
      .where(eq(taskCompletions.id, id))
      .returning();
    return result[0];
  }
}

// Export a singleton instance of the storage implementation
export const storage = new DbStorage();
