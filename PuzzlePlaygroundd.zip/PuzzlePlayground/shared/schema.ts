import { pgTable, text, serial, integer, boolean, timestamp, numeric, varchar, json, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  walletAddress: text("wallet_address").unique(),
  role: text("role").default("user").notNull(), // admin, user
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Airdrops table to manage different airdrop campaigns
export const airdrops = pgTable("airdrops", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenDecimals: integer("token_decimals").default(18).notNull(),
  description: text("description"),
  totalAmount: numeric("total_amount").notNull(),
  distributedAmount: numeric("distributed_amount").default("0").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  status: text("status").default("draft").notNull(), // draft, active, completed, cancelled
  requirements: jsonb("requirements"), // JSON field to store eligibility criteria
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Participants table to track users who are eligible for airdrops
export const participants = pgTable("participants", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  airdropId: integer("airdrop_id").references(() => airdrops.id),
  walletAddress: text("wallet_address").notNull(),
  eligibilityStatus: text("eligibility_status").default("pending").notNull(), // pending, eligible, ineligible
  claimStatus: text("claim_status").default("pending").notNull(), // pending, claimed, failed
  allocationAmount: numeric("allocation_amount"),
  proofOfEligibility: jsonb("proof_of_eligibility"), // Merkle proof or other verification data
  claimTxHash: text("claim_tx_hash"),
  claimDate: timestamp("claim_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Tasks for participants to complete to be eligible
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  airdropId: integer("airdrop_id").references(() => airdrops.id),
  name: text("name").notNull(),
  description: text("description"),
  points: integer("points").default(0).notNull(),
  type: text("type").notNull(), // social, quiz, referral, etc.
  requirements: jsonb("requirements"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Completions to track which tasks users have completed
export const taskCompletions = pgTable("task_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  taskId: integer("task_id").references(() => tasks.id),
  status: text("status").default("pending").notNull(), // pending, completed, rejected
  proofOfCompletion: jsonb("proof_of_completion"),
  verifiedAt: timestamp("verified_at"),
  verifiedBy: integer("verified_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Create schemas for inserting data
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  walletAddress: true,
});

export const insertAirdropSchema = createInsertSchema(airdrops).pick({
  name: true,
  tokenSymbol: true,
  tokenAddress: true,
  tokenDecimals: true,
  description: true,
  totalAmount: true,
  startDate: true,
  endDate: true,
  requirements: true,
  createdBy: true,
});

export const insertParticipantSchema = createInsertSchema(participants).pick({
  userId: true,
  airdropId: true,
  walletAddress: true,
  eligibilityStatus: true,
  allocationAmount: true,
  proofOfEligibility: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  airdropId: true,
  name: true,
  description: true,
  points: true,
  type: true,
  requirements: true,
});

export const insertTaskCompletionSchema = createInsertSchema(taskCompletions).pick({
  userId: true,
  taskId: true,
  status: true,
  proofOfCompletion: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertAirdrop = z.infer<typeof insertAirdropSchema>;
export type Airdrop = typeof airdrops.$inferSelect;

export type InsertParticipant = z.infer<typeof insertParticipantSchema>;
export type Participant = typeof participants.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertTaskCompletion = z.infer<typeof insertTaskCompletionSchema>;
export type TaskCompletion = typeof taskCompletions.$inferSelect;
