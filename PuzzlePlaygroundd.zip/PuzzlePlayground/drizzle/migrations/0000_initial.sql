CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "email" TEXT NOT NULL UNIQUE,
  "wallet_address" TEXT UNIQUE,
  "role" TEXT NOT NULL DEFAULT 'user',
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "airdrops" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "token_symbol" TEXT NOT NULL,
  "token_address" TEXT NOT NULL,
  "token_decimals" INTEGER NOT NULL DEFAULT 18,
  "description" TEXT,
  "total_amount" NUMERIC NOT NULL,
  "distributed_amount" NUMERIC NOT NULL DEFAULT '0',
  "start_date" TIMESTAMP NOT NULL,
  "end_date" TIMESTAMP,
  "status" TEXT NOT NULL DEFAULT 'draft',
  "requirements" JSONB,
  "created_by" INTEGER REFERENCES "users"("id"),
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "participants" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "airdrop_id" INTEGER REFERENCES "airdrops"("id"),
  "wallet_address" TEXT NOT NULL,
  "eligibility_status" TEXT NOT NULL DEFAULT 'pending',
  "claim_status" TEXT NOT NULL DEFAULT 'pending',
  "allocation_amount" NUMERIC,
  "proof_of_eligibility" JSONB,
  "claim_tx_hash" TEXT,
  "claim_date" TIMESTAMP,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "tasks" (
  "id" SERIAL PRIMARY KEY,
  "airdrop_id" INTEGER REFERENCES "airdrops"("id"),
  "name" TEXT NOT NULL,
  "description" TEXT,
  "points" INTEGER NOT NULL DEFAULT 0,
  "type" TEXT NOT NULL,
  "requirements" JSONB,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "task_completions" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER REFERENCES "users"("id"),
  "task_id" INTEGER REFERENCES "tasks"("id"),
  "status" TEXT NOT NULL DEFAULT 'pending',
  "proof_of_completion" JSONB,
  "verified_at" TIMESTAMP,
  "verified_by" INTEGER REFERENCES "users"("id"),
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL,
  CONSTRAINT "session_pkey" PRIMARY KEY ("sid")
);

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");