import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Pages
import Dashboard from './pages/Dashboard';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import AirdropList from './pages/airdrops/AirdropList';
import AirdropDetails from './pages/airdrops/AirdropDetails';
import CreateAirdrop from './pages/airdrops/CreateAirdrop';
import Profile from './pages/Profile';
import NotFound from './pages/not-found';
import Unauthorized from './pages/Unauthorized';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AirdropManagement from './pages/admin/AirdropManagement';
import AirdropEdit from './pages/admin/AirdropEdit';
import UserManagement from './pages/admin/UserManagement';

// Components
import AdminRoute from './components/AdminRoute';

// Context and utilities
import { AuthProvider, useAuth } from './lib/contexts/AuthContext';
import { queryClient } from './lib/queryClient';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
};

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <Routes>
            {/* Auth routes */}
            <Route element={<AuthLayout />}>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/unauthorized" element={<Unauthorized />} />
            </Route>
            
            {/* Admin routes */}
            <Route element={<MainLayout />}>
              <Route path="/admin" element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              } />
              
              <Route path="/admin/airdrops" element={
                <AdminRoute>
                  <AirdropManagement />
                </AdminRoute>
              } />
              
              <Route path="/admin/airdrops/create" element={
                <AdminRoute>
                  <CreateAirdrop isAdmin={true} />
                </AdminRoute>
              } />
              
              <Route path="/admin/airdrops/:id/edit" element={
                <AdminRoute>
                  <AirdropEdit />
                </AdminRoute>
              } />
              
              <Route path="/admin/users" element={
                <AdminRoute>
                  <UserManagement />
                </AdminRoute>
              } />
            </Route>
            
            {/* Main routes */}
            <Route element={<MainLayout />}>
              <Route path="/" element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } />
              
              <Route path="/airdrops" element={<AirdropList />} />
              
              <Route path="/airdrops/create" element={
                <ProtectedRoute>
                  <CreateAirdrop isAdmin={false} />
                </ProtectedRoute>
              } />
              
              <Route path="/airdrops/:id" element={<AirdropDetails />} />
              
              <Route path="/profile" element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              } />
              
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Router>
        
        <Toaster position="top-right" richColors />
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;