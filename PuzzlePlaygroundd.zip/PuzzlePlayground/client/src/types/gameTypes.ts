// Game phase types
export type GamePhase = "menu" | "playing" | "paused" | "complete";

// Puzzle types
export type PuzzleType = "color-matching" | "shape-sorting" | "memory";

// Difficulty levels
export type DifficultyLevel = "easy" | "medium" | "hard" | "adaptive";

// Player performance tracking
export interface Performance {
  correctAnswers: number;
  incorrectAnswers: number;
  timeSpent: number;
  currentStreak: number;
  longestStreak: number;
}

// Player progress
export interface PlayerProgress {
  level: number;
  score: number;
  stars: number;
  puzzlesCompleted: number;
  difficultyLevel: DifficultyLevel;
  performance: Performance;
}

// Color matching specific types
export interface ColorMatchingItem {
  id: string;
  color: string;
  position: [number, number, number];
  matched: boolean;
}

// Shape sorting specific types
export interface Shape {
  id: string;
  type: "circle" | "square" | "triangle" | "star" | "hexagon";
  color: string;
  position: [number, number, number];
  rotation: [number, number, number];
  size: number;
  matched: boolean;
}

// Memory game specific types
export interface MemoryCard {
  id: string;
  value: number;
  imageIndex: number;
  position: [number, number, number];
  flipped: boolean;
  matched: boolean;
}

// Settings
export interface GameSettings {
  volume: number;
  musicEnabled: boolean;
  soundEffectsEnabled: boolean;
  difficulty: DifficultyLevel;
  parentalControlsEnabled: boolean;
}

// Game state
export interface GameState {
  phase: GamePhase;
  currentPuzzle: PuzzleType | null;
  playerProgress: PlayerProgress;
  settings: GameSettings;
}
