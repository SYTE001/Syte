import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { toast } from 'sonner';
import { format } from 'date-fns';

import { Button } from '../../components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../../components/ui/form';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Calendar } from '../../components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Separator } from '../../components/ui/separator';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '../../components/ui/card';
import { CalendarIcon, Plus, Trash2, AlertCircle } from 'lucide-react';
import { cn } from '../../lib/utils';

// Define the schema for an airdrop requirement
const requirementSchema = z.object({
  type: z.enum(['followTwitter', 'joinTelegram', 'holdTokens', 'other']),
  value: z.string().min(1, 'Value is required'),
});

// Define the schema for the entire form
const formSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  tokenSymbol: z.string().min(1, 'Token symbol is required'),
  tokenAddress: z.string().min(42, 'Enter a valid token address'),
  tokenDecimals: z.number().int().min(0).max(18),
  totalAmount: z.string().min(1, 'Total amount is required'),
  startDate: z.date({
    required_error: 'Start date is required',
  }),
  endDate: z.date().optional(),
  description: z.string().optional(),
  requirements: z.array(requirementSchema).min(1, 'At least one requirement is needed'),
});

type FormValues = z.infer<typeof formSchema>;

const CreateAirdrop: React.FC = () => {
  const navigate = useNavigate();
  const [showCalendar, setShowCalendar] = useState<'start' | 'end' | null>(null);
  
  // Set up form with validation
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      tokenSymbol: '',
      tokenAddress: '',
      tokenDecimals: 18,
      totalAmount: '',
      startDate: new Date(),
      requirements: [
        { type: 'followTwitter', value: '' },
      ],
    },
  });
  
  // Set up field array for requirements
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'requirements',
  });
  
  // Create mutation for API request
  const createAirdropMutation = useMutation({
    mutationFn: (data: FormValues) => {
      // Format the data for the API
      const formattedData = {
        ...data,
        startDate: format(data.startDate, 'yyyy-MM-dd'),
        endDate: data.endDate ? format(data.endDate, 'yyyy-MM-dd') : null,
        totalAmount: data.totalAmount.toString(),
      };
      
      return apiRequest('/api/airdrops', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formattedData),
      });
    },
    onSuccess: () => {
      toast.success('Airdrop created successfully');
      navigate('/airdrops');
    },
    onError: (error) => {
      toast.error('Failed to create airdrop');
      console.error('Error creating airdrop:', error);
    },
  });
  
  // Handle form submission
  const onSubmit = async (data: FormValues) => {
    try {
      await createAirdropMutation.mutateAsync(data);
    } catch (error) {
      // Error is handled in the mutation callbacks
    }
  };
  
  const addRequirement = () => {
    append({ type: 'followTwitter', value: '' });
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Create Airdrop</h1>
        <p className="text-slate-600">Set up a new airdrop campaign for your token</p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>
                Provide the basic details about your airdrop
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Airdrop Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter airdrop name" {...field} />
                    </FormControl>
                    <FormDescription>
                      A clear name for your airdrop campaign
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="tokenSymbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Token Symbol</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. ETH" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="tokenDecimals"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Token Decimals</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="18" 
                          min={0}
                          max={18}
                          {...field}
                          onChange={(e) => {
                            const value = parseInt(e.target.value);
                            field.onChange(isNaN(value) ? 0 : value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="tokenAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Token Contract Address</FormLabel>
                    <FormControl>
                      <Input placeholder="0x..." {...field} />
                    </FormControl>
                    <FormDescription>
                      The Ethereum contract address of the token
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter a description for your airdrop"
                        className="resize-none min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Distribution Details</CardTitle>
              <CardDescription>
                Configure how your tokens will be distributed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="totalAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Token Amount</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. 100000" {...field} />
                    </FormControl>
                    <FormDescription>
                      The total number of tokens to be distributed in this airdrop
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover open={showCalendar === 'start'} onOpenChange={(open) => {
                        if (open) setShowCalendar('start');
                        else setShowCalendar(null);
                      }}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={(date) => {
                              field.onChange(date);
                              setShowCalendar(null);
                            }}
                            disabled={(date) => date < new Date("1900-01-01")}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        When the airdrop will begin
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date (Optional)</FormLabel>
                      <Popover open={showCalendar === 'end'} onOpenChange={(open) => {
                        if (open) setShowCalendar('end');
                        else setShowCalendar(null);
                      }}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>No end date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value || undefined}
                            onSelect={(date) => {
                              field.onChange(date);
                              setShowCalendar(null);
                            }}
                            disabled={(date) => {
                              const startDate = form.getValues('startDate');
                              return date < startDate || date < new Date("1900-01-01");
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        When the airdrop will end (leave empty for no end date)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Eligibility Requirements</CardTitle>
                  <CardDescription>
                    Define the criteria users must meet to be eligible
                  </CardDescription>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addRequirement}
                  disabled={fields.length >= 5}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Requirement
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {fields.length === 0 && (
                <div className="flex items-center justify-center p-4 border border-dashed rounded-md">
                  <div className="flex flex-col items-center text-center">
                    <AlertCircle className="h-8 w-8 text-slate-400 mb-2" />
                    <p className="text-sm text-slate-600">No requirements added</p>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="mt-2"
                      onClick={addRequirement}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Requirement
                    </Button>
                  </div>
                </div>
              )}
              
              {fields.map((field, index) => (
                <div key={field.id} className="flex flex-col space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium">Requirement {index + 1}</h4>
                    {fields.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => remove(index)}
                        className="h-8 w-8 p-0"
                      >
                        <span className="sr-only">Remove requirement</span>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <FormField
                      control={form.control}
                      name={`requirements.${index}.type`}
                      render={({ field }) => (
                        <FormItem>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="followTwitter">Follow Twitter</SelectItem>
                              <SelectItem value="joinTelegram">Join Telegram</SelectItem>
                              <SelectItem value="holdTokens">Hold Tokens</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="md:col-span-2">
                      <FormField
                        control={form.control}
                        name={`requirements.${index}.value`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input
                                placeholder={getRequirementPlaceholder(form.watch(`requirements.${index}.type`))}
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {index !== fields.length - 1 && (
                    <Separator className="my-2" />
                  )}
                </div>
              ))}
            </CardContent>
            
            <CardFooter className="flex justify-between">
              <Button 
                type="button"
                variant="outline"
                onClick={() => navigate('/airdrops')}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createAirdropMutation.isPending}
              >
                {createAirdropMutation.isPending ? 'Creating...' : 'Create Airdrop'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>
    </div>
  );
};

// Helper function to get placeholder text based on requirement type
function getRequirementPlaceholder(type: string): string {
  switch (type) {
    case 'followTwitter':
      return 'Twitter username (e.g. @example)';
    case 'joinTelegram':
      return 'Telegram group link';
    case 'holdTokens':
      return 'Minimum token amount required';
    case 'other':
      return 'Describe requirement';
    default:
      return 'Enter value';
  }
}

export default CreateAirdrop;