import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { useAuth } from '../../lib/contexts/AuthContext';
import { toast } from 'sonner';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Separator } from '../../components/ui/separator';
import { Progress } from '../../components/ui/progress';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../../components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../components/ui/alert-dialog';

import StatusBadge from '../../components/airdrop/StatusBadge';
import { formatDate, formatNumber, truncateAddress } from '../../lib/utils';
import {
  Calendar,
  ChevronLeft,
  Coins,
  Copy,
  ExternalLink,
  Info,
  Users,
  Clock,
  FileCheck,
  CheckCircle2,
  Ban,
  AlertTriangle,
  Edit,
  Trash2,
} from 'lucide-react';

interface Task {
  id: number;
  airdropId: number;
  type: string;
  description: string;
  value: string;
  createdAt: string;
}

interface Participant {
  id: number;
  userId: number;
  airdropId: number;
  eligibilityStatus: string;
  claimStatus: string;
  allocationAmount: string | null;
  claimTxHash: string | null;
  claimDate: string | null;
  createdAt: string;
  user: {
    username: string;
    email: string;
    walletAddress: string;
  };
}

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  tokenAddress: string;
  tokenDecimals: number;
  description: string | null;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
  createdBy: number;
}

const AirdropDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  // Fetch airdrop details
  const { data: airdrop, isLoading: isLoadingAirdrop } = useQuery({
    queryKey: ['airdrop', id],
    queryFn: () => apiRequest<Airdrop>(`/api/airdrops/${id}`),
    enabled: !!id,
  });
  
  // Fetch airdrop tasks (requirements)
  const { data: tasks, isLoading: isLoadingTasks } = useQuery({
    queryKey: ['airdrop-tasks', id],
    queryFn: () => apiRequest<Task[]>(`/api/airdrops/${id}/tasks`),
    enabled: !!id,
  });
  
  // Fetch airdrop participants
  const { data: participants, isLoading: isLoadingParticipants } = useQuery({
    queryKey: ['airdrop-participants', id],
    queryFn: () => apiRequest<Participant[]>(`/api/airdrops/${id}/participants`),
    enabled: !!id && activeTab === 'participants',
  });
  
  // Check if current user is a participant
  const { data: userParticipation } = useQuery({
    queryKey: ['user-participation', id],
    queryFn: () => apiRequest<Participant | null>(`/api/airdrops/${id}/user-participation`),
    enabled: !!id && !!user,
  });
  
  // Mutation to join airdrop
  const joinAirdropMutation = useMutation({
    mutationFn: () => apiRequest(`/api/airdrops/${id}/join`, { method: 'POST' }),
    onSuccess: () => {
      toast.success('Successfully joined airdrop!');
      queryClient.invalidateQueries({ queryKey: ['user-participation', id] });
    },
    onError: (error) => {
      toast.error('Failed to join airdrop');
      console.error('Error joining airdrop:', error);
    },
  });
  
  // Mutation to claim tokens
  const claimTokensMutation = useMutation({
    mutationFn: () => apiRequest(`/api/airdrops/${id}/claim`, { method: 'POST' }),
    onSuccess: () => {
      toast.success('Successfully claimed tokens!');
      queryClient.invalidateQueries({ queryKey: ['user-participation', id] });
      queryClient.invalidateQueries({ queryKey: ['airdrop', id] });
    },
    onError: (error) => {
      toast.error('Failed to claim tokens');
      console.error('Error claiming tokens:', error);
    },
  });
  
  // Mutation to delete airdrop
  const deleteAirdropMutation = useMutation({
    mutationFn: () => apiRequest(`/api/airdrops/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast.success('Airdrop deleted successfully');
      navigate('/airdrops');
    },
    onError: (error) => {
      toast.error('Failed to delete airdrop');
      console.error('Error deleting airdrop:', error);
    },
  });
  
  // Handle join airdrop
  const handleJoinAirdrop = () => {
    joinAirdropMutation.mutate();
  };
  
  // Handle claim tokens
  const handleClaimTokens = () => {
    claimTokensMutation.mutate();
  };
  
  // Handle delete airdrop
  const handleDeleteAirdrop = () => {
    deleteAirdropMutation.mutate();
  };
  
  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };
  
  // Helper to determine if user is the creator of this airdrop
  const isCreator = user && airdrop && user.id === airdrop.createdBy;
  
  // Calculate distribution percentage
  const distributionPercentage = airdrop
    ? Math.min(Math.round((parseFloat(airdrop.distributedAmount) / parseFloat(airdrop.totalAmount)) * 100), 100)
    : 0;
  
  if (isLoadingAirdrop) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Loading airdrop details...</p>
        </div>
      </div>
    );
  }
  
  if (!airdrop) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Airdrop Not Found</h2>
          <p className="text-slate-600 mb-4">This airdrop may have been removed or doesn't exist.</p>
          <Button asChild>
            <Link to="/airdrops">Back to Airdrops</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Back button and title */}
      <div className="flex flex-wrap justify-between items-start gap-4">
        <div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ChevronLeft className="mr-2 h-4 w-4" /> Back
          </Button>
          
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{airdrop.name}</h1>
            <StatusBadge status={airdrop.status} />
          </div>
          
          <div className="text-slate-600 flex items-center mt-1">
            <Coins className="h-4 w-4 mr-1 inline" />
            {airdrop.tokenSymbol} Token Airdrop
          </div>
        </div>
        
        {isCreator && (
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <Link to={`/airdrops/${id}/edit`}>
                <Edit className="mr-2 h-4 w-4" /> Edit
              </Link>
            </Button>
            
            <Button 
              variant="destructive" 
              onClick={() => setIsDeleteDialogOpen(true)}
            >
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          </div>
        )}
      </div>
      
      {/* Action card for joining/claiming */}
      {user && (
        <Card className="bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
              <div>
                <h3 className="text-lg font-medium mb-1">
                  {userParticipation ? 'You have joined this airdrop' : 'Join this airdrop campaign'}
                </h3>
                <p className="text-slate-600 text-sm">
                  {userParticipation
                    ? userParticipation.eligibilityStatus === 'eligible'
                      ? userParticipation.claimStatus === 'claimed'
                        ? `You've successfully claimed ${userParticipation.allocationAmount} ${airdrop.tokenSymbol}`
                        : `You're eligible to claim ${userParticipation.allocationAmount} ${airdrop.tokenSymbol}`
                      : 'Complete all requirements to become eligible'
                    : 'Join this airdrop to check your eligibility for token distribution'}
                </p>
              </div>
              
              <div>
                {!userParticipation ? (
                  <Button 
                    onClick={handleJoinAirdrop} 
                    disabled={joinAirdropMutation.isPending}
                  >
                    {joinAirdropMutation.isPending ? 'Joining...' : 'Join Airdrop'}
                  </Button>
                ) : userParticipation.eligibilityStatus === 'eligible' && 
                   userParticipation.claimStatus !== 'claimed' && 
                   airdrop.status === 'active' ? (
                  <Button 
                    onClick={handleClaimTokens} 
                    disabled={claimTokensMutation.isPending}
                  >
                    {claimTokensMutation.isPending ? 'Claiming...' : 'Claim Tokens'}
                  </Button>
                ) : userParticipation.claimStatus === 'claimed' ? (
                  <Button variant="outline" disabled>
                    <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" /> Claimed
                  </Button>
                ) : (
                  <Button variant="outline" disabled>
                    {userParticipation.eligibilityStatus === 'ineligible' ? (
                      <>
                        <Ban className="mr-2 h-4 w-4 text-red-500" /> Ineligible
                      </>
                    ) : (
                      <>
                        <Clock className="mr-2 h-4 w-4 text-yellow-500" /> Pending
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Tabs for different sections */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full sm:w-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="requirements">Requirements</TabsTrigger>
          <TabsTrigger value="participants">Participants</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Distribution Info */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Distribution Details</CardTitle>
                <CardDescription>Information about token distribution</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-slate-600">Distribution Progress</span>
                    <span className="text-sm font-medium">{distributionPercentage}%</span>
                  </div>
                  <Progress value={distributionPercentage} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-600">Total Token Amount:</span>
                    <span className="font-medium">{formatNumber(airdrop.totalAmount)} {airdrop.tokenSymbol}</span>
                  </div>
                  
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-600">Distributed Amount:</span>
                    <span className="font-medium">{formatNumber(airdrop.distributedAmount)} {airdrop.tokenSymbol}</span>
                  </div>
                  
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-600">Remaining Amount:</span>
                    <span className="font-medium">
                      {formatNumber(
                        (parseFloat(airdrop.totalAmount) - parseFloat(airdrop.distributedAmount)).toString()
                      )} {airdrop.tokenSymbol}
                    </span>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-600 flex items-center">
                      <Calendar className="h-3.5 w-3.5 mr-1" /> Start Date:
                    </span>
                    <span className="font-medium">{formatDate(airdrop.startDate)}</span>
                  </div>
                  
                  {airdrop.endDate && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-600 flex items-center">
                        <Calendar className="h-3.5 w-3.5 mr-1" /> End Date:
                      </span>
                      <span className="font-medium">{formatDate(airdrop.endDate)}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-600 flex items-center">
                      <Clock className="h-3.5 w-3.5 mr-1" /> Created At:
                    </span>
                    <span className="font-medium">{formatDate(airdrop.createdAt, true)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Token Info */}
            <Card>
              <CardHeader>
                <CardTitle>Token Information</CardTitle>
                <CardDescription>Details about the token being distributed</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="text-sm font-medium mb-1">Token Symbol</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-900 dark:text-slate-100">{airdrop.tokenSymbol}</span>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Token Decimals</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-900 dark:text-slate-100">{airdrop.tokenDecimals}</span>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Contract Address</h4>
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-slate-100 dark:bg-slate-800 p-1 rounded">
                      {truncateAddress(airdrop.tokenAddress)}
                    </code>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(airdrop.tokenAddress)}
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6"
                      onClick={() => window.open(`https://etherscan.io/token/${airdrop.tokenAddress}`, '_blank')}
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Description Card */}
          {airdrop.description && (
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 whitespace-pre-line">{airdrop.description}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        {/* Requirements Tab */}
        <TabsContent value="requirements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Eligibility Requirements</CardTitle>
              <CardDescription>
                Complete these requirements to be eligible for the airdrop
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingTasks ? (
                <div className="text-center py-6">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
                  <p className="text-sm text-slate-600">Loading requirements...</p>
                </div>
              ) : !tasks || tasks.length === 0 ? (
                <div className="text-center py-6">
                  <Info className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-600">No requirements specified for this airdrop.</p>
                </div>
              ) : (
                <ul className="space-y-4">
                  {tasks.map((task, index) => (
                    <li key={task.id} className="border p-4 rounded-md">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="bg-slate-200 dark:bg-slate-700 text-xs px-2 py-1 rounded">
                              Requirement {index + 1}
                            </span>
                            <h4 className="font-medium">{getTaskTypeLabel(task.type)}</h4>
                          </div>
                          <p className="text-sm text-slate-600 mt-1">{task.description || task.value}</p>
                        </div>
                        
                        {userParticipation && (
                          <div className="ml-4">
                            {isTaskCompleted(task, userParticipation) ? (
                              <div className="flex items-center text-green-600">
                                <CheckCircle2 className="h-4 w-4 mr-1" />
                                <span className="text-xs">Completed</span>
                              </div>
                            ) : (
                              <div className="flex items-center text-slate-400">
                                <Clock className="h-4 w-4 mr-1" />
                                <span className="text-xs">Pending</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
            <CardFooter className="border-t px-6 py-4 bg-slate-50 dark:bg-slate-900">
              <div className="flex items-center text-sm text-slate-600">
                <FileCheck className="h-4 w-4 mr-2 text-slate-500" />
                Complete all requirements to be eligible for the airdrop
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Participants Tab */}
        <TabsContent value="participants" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Participants</CardTitle>
                  <CardDescription>
                    Users who have joined this airdrop campaign
                  </CardDescription>
                </div>
                
                {participants && (
                  <div className="flex items-center bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
                    <Users className="h-4 w-4 mr-2 text-slate-500" />
                    <span className="text-sm font-medium">{participants.length} Participants</span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingParticipants ? (
                <div className="text-center py-6">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
                  <p className="text-sm text-slate-600">Loading participants...</p>
                </div>
              ) : !participants || participants.length === 0 ? (
                <div className="text-center py-6">
                  <Users className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-600">No participants have joined this airdrop yet.</p>
                </div>
              ) : (
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Wallet Address</TableHead>
                        <TableHead>Eligibility</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {participants.map((participant) => (
                        <TableRow key={participant.id}>
                          <TableCell>
                            {participant.user.username || truncateAddress(participant.user.walletAddress)}
                          </TableCell>
                          <TableCell className="font-mono text-xs">
                            {truncateAddress(participant.user.walletAddress)}
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={participant.eligibilityStatus} />
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={participant.claimStatus} />
                          </TableCell>
                          <TableCell className="text-right">
                            {participant.allocationAmount 
                              ? `${participant.allocationAmount} ${airdrop.tokenSymbol}`
                              : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this airdrop?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the airdrop
              and all associated data including participants and allocations.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteAirdrop}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {deleteAirdropMutation.isPending ? 'Deleting...' : 'Delete Airdrop'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

// Helper to get label for task type
function getTaskTypeLabel(type: string): string {
  switch (type) {
    case 'followTwitter':
      return 'Follow on Twitter';
    case 'joinTelegram':
      return 'Join Telegram Group';
    case 'holdTokens':
      return 'Hold Token Requirement';
    case 'other':
      return 'Custom Requirement';
    default:
      return type;
  }
}

// Helper to check if a task is completed (dummy implementation)
function isTaskCompleted(task: Task, participation: Participant): boolean {
  // This is a placeholder implementation 
  // In a real app, you would check against completed tasks data
  return participation.eligibilityStatus === 'eligible';
}

export default AirdropDetails;