import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { Button } from '../../components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from '../../components/ui/select';
import { Input } from '../../components/ui/input';
import { Plus, Filter, Search, SortDesc, SortAsc } from 'lucide-react';
import AirdropCard from '../../components/airdrop/AirdropCard';

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  description?: string;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
}

type SortField = 'name' | 'totalAmount' | 'startDate';
type SortDirection = 'asc' | 'desc';

const AirdropList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('startDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  
  const { data: airdrops, isLoading } = useQuery({
    queryKey: ['airdrops'],
    queryFn: () => apiRequest<Airdrop[]>('/api/airdrops'),
  });
  
  const filteredAirdrops = airdrops ? airdrops
    .filter(airdrop => {
      const matchesSearch = !searchTerm || 
        airdrop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        airdrop.tokenSymbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (airdrop.description && airdrop.description.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesStatus = !statusFilter || airdrop.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let valueA, valueB;
      
      if (sortField === 'name') {
        valueA = a.name.toLowerCase();
        valueB = b.name.toLowerCase();
      } else if (sortField === 'totalAmount') {
        valueA = parseFloat(a.totalAmount);
        valueB = parseFloat(b.totalAmount);
      } else {
        valueA = new Date(a.startDate).getTime();
        valueB = new Date(b.startDate).getTime();
      }
      
      return sortDirection === 'asc' 
        ? (valueA > valueB ? 1 : -1) 
        : (valueA < valueB ? 1 : -1);
    }) : [];
  
  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">All Airdrops</h1>
          <p className="text-slate-600">Browse and filter all available airdrops</p>
        </div>
        
        <Button asChild>
          <Link to="/airdrops/create">
            <Plus className="mr-2 h-4 w-4" /> Create Airdrop
          </Link>
        </Button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          <Input
            placeholder="Search airdrops..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <div className="w-40">
            <Select value={statusFilter || ''} onValueChange={(value) => setStatusFilter(value || null)}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Status" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Filter by Status</SelectLabel>
                  <SelectItem value="">All</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-48">
            <Select value={sortField} onValueChange={(value) => setSortField(value as SortField)}>
              <SelectTrigger>
                <div className="flex items-center">
                  {sortDirection === 'asc' ? (
                    <SortAsc className="mr-2 h-4 w-4" />
                  ) : (
                    <SortDesc className="mr-2 h-4 w-4" />
                  )}
                  <SelectValue placeholder="Sort by" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Sort by</SelectLabel>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="totalAmount">Amount</SelectItem>
                  <SelectItem value="startDate">Date</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="outline" size="icon" onClick={toggleSortDirection}>
            {sortDirection === 'asc' ? (
              <SortAsc className="h-4 w-4" />
            ) : (
              <SortDesc className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="py-8 text-center">Loading airdrops...</div>
      ) : filteredAirdrops.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAirdrops.map(airdrop => (
            <AirdropCard key={airdrop.id} airdrop={airdrop} />
          ))}
        </div>
      ) : (
        <div className="py-8 text-center">
          {searchTerm || statusFilter ? (
            <p>No airdrops found with the current filters.</p>
          ) : (
            <p>No airdrops available yet.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default AirdropList;