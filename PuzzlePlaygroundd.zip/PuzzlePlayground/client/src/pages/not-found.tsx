import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { FileX } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <FileX className="h-24 w-24 text-slate-400 mb-6" />
      
      <h1 className="text-3xl font-bold tracking-tight mb-2">
        404 - Page Not Found
      </h1>
      
      <p className="text-slate-600 mb-8 max-w-md">
        The page you are looking for might have been removed, had its name changed, 
        or is temporarily unavailable.
      </p>
      
      <div className="flex flex-wrap gap-4 justify-center">
        <Button asChild>
          <Link to="/">Go to Dashboard</Link>
        </Button>
        
        <Button variant="outline" asChild>
          <Link to="/airdrops">View Airdrops</Link>
        </Button>
      </div>
    </div>
  );
}