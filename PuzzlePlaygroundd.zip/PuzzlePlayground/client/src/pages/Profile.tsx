import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../lib/contexts/AuthContext';
import { toast } from 'sonner';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Separator } from '../components/ui/separator';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../components/ui/form';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../components/ui/alert-dialog';

import StatusBadge from '../components/airdrop/StatusBadge';
import { formatDate, formatNumber, truncateAddress, getInitials } from '../lib/utils';
import { 
  User, 
  Wallet, 
  Copy, 
  ExternalLink, 
  ChevronRight, 
  CheckCircle2,
  Clock,
  Ban,
  Edit,
  Save,
  X
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

interface Participant {
  id: number;
  airdropId: number;
  eligibilityStatus: string;
  claimStatus: string;
  allocationAmount: string | null;
  claimTxHash: string | null;
  claimDate: string | null;
  createdAt: string;
}

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  totalAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
}

interface ParticipationWithAirdrop extends Participant {
  airdrop: Airdrop;
}

const profileSchema = z.object({
  username: z.string().optional(),
  email: z.string().email('Please enter a valid email').optional(),
  walletAddress: z
    .string()
    .min(42, 'Wallet address must be at least 42 characters')
    .optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  
  // Form for profile editing
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      username: user?.username || '',
      email: user?.email || '',
      walletAddress: user?.walletAddress || '',
    },
  });
  
  // Fetch user participations
  const { data: participations, isLoading: isLoadingParticipations } = useQuery({
    queryKey: ['user-participations'],
    queryFn: () => apiRequest<ParticipationWithAirdrop[]>('/api/user/participations'),
    enabled: !!user,
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: (data: ProfileFormValues) => 
      apiRequest('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      toast.success('Profile updated successfully');
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
    },
    onError: (error) => {
      toast.error('Failed to update profile');
      console.error('Error updating profile:', error);
    },
  });
  
  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };
  
  // Handle form submission
  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };
  
  // Cancel editing
  const cancelEditing = () => {
    form.reset({
      username: user?.username || '',
      email: user?.email || '',
      walletAddress: user?.walletAddress || '',
    });
    setIsEditing(false);
  };
  
  // Handle logout
  const handleLogout = () => {
    logout();
    setShowLogoutConfirm(false);
  };
  
  if (!user) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Loading profile...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Your Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Profile Information</CardTitle>
              {!isEditing ? (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setIsEditing(true)}
                >
                  <Edit className="h-4 w-4 mr-2" /> Edit
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={cancelEditing}
                  >
                    <X className="h-4 w-4 mr-1" /> Cancel
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={form.handleSubmit(onSubmit)}
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? (
                      <div className="flex items-center">
                        <div className="animate-spin h-4 w-4 mr-2 border-b-2 border-white rounded-full"></div>
                        Saving...
                      </div>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-1" /> Save
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center">
              <Avatar className="h-24 w-24 mb-4">
                <AvatarFallback className="text-xl bg-primary text-primary-foreground">
                  {getInitials(user.username || user.email || truncateAddress(user.walletAddress))}
                </AvatarFallback>
              </Avatar>
              
              {isEditing ? (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 w-full">
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="walletAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Wallet Address</FormLabel>
                          <FormControl>
                            <Input placeholder="0x..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </form>
                </Form>
              ) : (
                <>
                  <h2 className="text-xl font-bold mb-1">
                    {user.username || truncateAddress(user.walletAddress)}
                  </h2>
                  
                  {user.email && (
                    <p className="text-slate-600 mb-4">{user.email}</p>
                  )}
                  
                  <div className="w-full space-y-3 mt-2">
                    <div className="flex items-center p-2 bg-slate-50 dark:bg-slate-900 rounded-md">
                      <Wallet className="h-5 w-5 text-slate-500 mr-3" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">Wallet Address</p>
                        <p className="text-xs text-slate-500 truncate">
                          {user.walletAddress}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => copyToClipboard(user.walletAddress)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => window.open(`https://etherscan.io/address/${user.walletAddress}`, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-2 bg-slate-50 dark:bg-slate-900 rounded-md">
                      <User className="h-5 w-5 text-slate-500 mr-3" />
                      <div>
                        <p className="text-sm font-medium">Account Type</p>
                        <p className="text-xs text-slate-500">
                          {user.isAdmin ? 'Administrator' : 'Standard User'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-2 bg-slate-50 dark:bg-slate-900 rounded-md">
                      <Clock className="h-5 w-5 text-slate-500 mr-3" />
                      <div>
                        <p className="text-sm font-medium">Joined</p>
                        <p className="text-xs text-slate-500">
                          {formatDate(user.createdAt, true)}
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </CardContent>
          
          <CardFooter className="border-t p-4 flex justify-center">
            <Button 
              variant="outline" 
              className="w-full" 
              onClick={() => setShowLogoutConfirm(true)}
            >
              Log Out
            </Button>
          </CardFooter>
        </Card>
        
        {/* Airdrops and Activity */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Airdrops</CardTitle>
              <CardDescription>
                Airdrops you've participated in
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingParticipations ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-slate-600">Loading your airdrops...</p>
                </div>
              ) : !participations || participations.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-600 mb-4">You haven't participated in any airdrops yet.</p>
                  <Button asChild>
                    <Link to="/airdrops">Browse Airdrops</Link>
                  </Button>
                </div>
              ) : (
                <div className="rounded-md border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Airdrop</TableHead>
                        <TableHead>Token</TableHead>
                        <TableHead>Eligibility</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {participations.map((participation) => (
                        <TableRow key={participation.id}>
                          <TableCell className="font-medium">
                            {participation.airdrop.name}
                          </TableCell>
                          <TableCell>{participation.airdrop.tokenSymbol}</TableCell>
                          <TableCell>
                            <StatusBadge status={participation.eligibilityStatus} />
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={participation.claimStatus} />
                          </TableCell>
                          <TableCell className="text-right">
                            {participation.allocationAmount 
                              ? `${formatNumber(participation.allocationAmount)} ${participation.airdrop.tokenSymbol}`
                              : '-'}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="icon" asChild>
                              <Link to={`/airdrops/${participation.airdropId}`}>
                                <ChevronRight className="h-4 w-4" />
                              </Link>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Activity Summary</CardTitle>
              <CardDescription>
                Overview of your activity on the platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-slate-500">Participations</h3>
                    <Ban className="h-4 w-4 text-slate-400" />
                  </div>
                  <p className="text-2xl font-bold">{participations?.length || 0}</p>
                  <p className="text-xs text-slate-500 mt-1">Total airdrops joined</p>
                </div>
                
                <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-slate-500">Eligible</h3>
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  </div>
                  <p className="text-2xl font-bold">
                    {participations?.filter(p => p.eligibilityStatus === 'eligible').length || 0}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Airdrops eligible for</p>
                </div>
                
                <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-slate-500">Claimed</h3>
                    <Wallet className="h-4 w-4 text-blue-500" />
                  </div>
                  <p className="text-2xl font-bold">
                    {participations?.filter(p => p.claimStatus === 'claimed').length || 0}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">Airdrops successfully claimed</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Logout Confirmation Dialog */}
      <AlertDialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to log out?</AlertDialogTitle>
            <AlertDialogDescription>
              You will need to log in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleLogout}>Log Out</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Profile;