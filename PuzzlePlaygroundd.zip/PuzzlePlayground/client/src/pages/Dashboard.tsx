import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../lib/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { formatDate, formatNumber, getStatusColor } from '../lib/utils';
import { Gift, Calendar, Coins, Users, Plus, ExternalLink } from 'lucide-react';
import AirdropCard from '../components/airdrop/AirdropCard';

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
}

interface Participant {
  id: number;
  airdropId: number;
  eligibilityStatus: string;
  claimStatus: string;
  allocationAmount: string | null;
}

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  const { data: airdrops, isLoading: isLoadingAirdrops } = useQuery({
    queryKey: ['airdrops'],
    queryFn: () => apiRequest<Airdrop[]>('/api/airdrops'),
  });
  
  const { data: userParticipations, isLoading: isLoadingParticipations } = useQuery({
    queryKey: ['participations', user?.id],
    queryFn: () => apiRequest<Participant[]>(`/api/users/${user?.id}/participations`),
    enabled: !!user,
  });
  
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-slate-600">Manage your airdrops and participations</p>
        </div>
        
        <Button asChild>
          <Link to="/airdrops/create">
            <Plus className="mr-2 h-4 w-4" /> Create Airdrop
          </Link>
        </Button>
      </div>
      
      {user && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Active Airdrops</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Gift className="mr-2 h-5 w-5 text-blue-500" />
                <div className="text-2xl font-bold">
                  {isLoadingAirdrops ? (
                    <span className="text-slate-300">Loading...</span>
                  ) : (
                    airdrops?.filter(airdrop => airdrop.status === 'active').length || 0
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Your Participations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="mr-2 h-5 w-5 text-green-500" />
                <div className="text-2xl font-bold">
                  {isLoadingParticipations ? (
                    <span className="text-slate-300">Loading...</span>
                  ) : (
                    userParticipations?.length || 0
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Eligible Airdrops</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Coins className="mr-2 h-5 w-5 text-yellow-500" />
                <div className="text-2xl font-bold">
                  {isLoadingParticipations ? (
                    <span className="text-slate-300">Loading...</span>
                  ) : (
                    userParticipations?.filter(p => p.eligibilityStatus === 'eligible').length || 0
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Claimed Airdrops</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-purple-500" />
                <div className="text-2xl font-bold">
                  {isLoadingParticipations ? (
                    <span className="text-slate-300">Loading...</span>
                  ) : (
                    userParticipations?.filter(p => p.claimStatus === 'claimed').length || 0
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="active">Active Airdrops</TabsTrigger>
          <TabsTrigger value="all">All Airdrops</TabsTrigger>
          {user && <TabsTrigger value="participating">Participating</TabsTrigger>}
        </TabsList>
        
        <TabsContent value="active" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoadingAirdrops ? (
              <p>Loading airdrops...</p>
            ) : airdrops?.length ? (
              airdrops
                .filter(airdrop => airdrop.status === 'active')
                .map(airdrop => (
                  <AirdropCard key={airdrop.id} airdrop={airdrop} />
                ))
            ) : (
              <p>No active airdrops found.</p>
            )}
          </div>
          
          {airdrops && airdrops.filter(airdrop => airdrop.status === 'active').length > 0 && (
            <div className="flex justify-center mt-4">
              <Button variant="outline" asChild>
                <Link to="/airdrops">View All Airdrops</Link>
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoadingAirdrops ? (
              <p>Loading airdrops...</p>
            ) : airdrops?.length ? (
              airdrops
                .slice(0, 6)
                .map(airdrop => (
                  <AirdropCard key={airdrop.id} airdrop={airdrop} />
                ))
            ) : (
              <p>No airdrops found.</p>
            )}
          </div>
          
          {airdrops && airdrops.length > 6 && (
            <div className="flex justify-center mt-4">
              <Button variant="outline" asChild>
                <Link to="/airdrops">View All Airdrops</Link>
              </Button>
            </div>
          )}
        </TabsContent>
        
        {user && (
          <TabsContent value="participating" className="space-y-4">
            {isLoadingParticipations || isLoadingAirdrops ? (
              <p>Loading your participations...</p>
            ) : userParticipations?.length && airdrops?.length ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userParticipations.slice(0, 6).map(participation => {
                  const matchingAirdrop = airdrops.find(a => a.id === participation.airdropId);
                  if (!matchingAirdrop) return null;
                  
                  return (
                    <Card key={participation.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle>{matchingAirdrop.name}</CardTitle>
                          <Badge
                            variant="outline"
                            className={getStatusColor(participation.eligibilityStatus)}
                          >
                            {participation.eligibilityStatus}
                          </Badge>
                        </div>
                        <CardDescription>
                          {matchingAirdrop.tokenSymbol} - {formatNumber(matchingAirdrop.totalAmount)}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Start Date:</span>
                            <span>{formatDate(matchingAirdrop.startDate)}</span>
                          </div>
                          {matchingAirdrop.endDate && (
                            <div className="flex justify-between">
                              <span className="text-slate-500">End Date:</span>
                              <span>{formatDate(matchingAirdrop.endDate)}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-slate-500">Claim Status:</span>
                            <Badge
                              variant="outline"
                              className={getStatusColor(participation.claimStatus)}
                            >
                              {participation.claimStatus}
                            </Badge>
                          </div>
                          {participation.allocationAmount && (
                            <div className="flex justify-between">
                              <span className="text-slate-500">Allocation:</span>
                              <span className="font-semibold">
                                {formatNumber(participation.allocationAmount)} {matchingAirdrop.tokenSymbol}
                              </span>
                            </div>
                          )}
                        </div>
                      </CardContent>
                      <CardFooter className="pt-0">
                        <Button variant="outline" className="w-full" asChild>
                          <Link to={`/airdrops/${matchingAirdrop.id}`}>
                            <ExternalLink className="mr-2 h-4 w-4" /> View Details
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <p>You are not participating in any airdrops yet.</p>
            )}
            
            {userParticipations && userParticipations.length > 6 && (
              <div className="flex justify-center mt-4">
                <Button variant="outline" asChild>
                  <Link to="/profile">View All Participations</Link>
                </Button>
              </div>
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default Dashboard;