import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { ShieldAlert } from 'lucide-react';

const Unauthorized: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <ShieldAlert className="h-24 w-24 text-red-500 mb-6" />
      
      <h1 className="text-3xl font-bold tracking-tight mb-2">
        Akses Ditolak
      </h1>
      
      <p className="text-slate-600 mb-8 max-w-md">
        Maaf, Anda tidak memiliki izin untuk mengakses halaman ini. 
        Halaman ini hanya tersedia untuk administrator.
      </p>
      
      <div className="flex flex-wrap gap-4 justify-center">
        <Button asChild>
          <Link to="/">Kembali ke Dashboard</Link>
        </Button>
        
        <Button variant="outline" asChild>
          <Link to="/airdrops">Lihat Airdrops</Link>
        </Button>
      </div>
    </div>
  );
};

export default Unauthorized;