import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { toast } from 'sonner';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../../components/ui/form';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Separator } from '../../components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import { Calendar } from '../../components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../components/ui/popover';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../components/ui/alert-dialog';

import { ChevronLeft, CalendarIcon, Plus, Trash2, AlertCircle } from 'lucide-react';
import { cn } from '../../lib/utils';

// Define interfaces
interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  tokenAddress: string;
  tokenDecimals: number;
  description: string | null;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
  createdBy: number;
}

interface Task {
  id: number;
  airdropId: number;
  type: string;
  value: string;
  description: string | null;
  createdAt: string;
}

// Define the schema for an airdrop requirement
const requirementSchema = z.object({
  id: z.number().optional(),
  type: z.enum(['followTwitter', 'joinTelegram', 'holdTokens', 'other']),
  value: z.string().min(1, 'Nilai diperlukan'),
  description: z.string().optional(),
});

// Define the schema for the edit form
const formSchema = z.object({
  name: z.string().min(3, 'Nama harus minimal 3 karakter'),
  tokenSymbol: z.string().min(1, 'Symbol token diperlukan'),
  tokenAddress: z.string().min(42, 'Masukkan alamat token yang valid'),
  tokenDecimals: z.number().int().min(0).max(18),
  totalAmount: z.string().min(1, 'Jumlah total diperlukan'),
  startDate: z.date({
    required_error: 'Tanggal mulai diperlukan',
  }),
  endDate: z.date().optional(),
  description: z.string().optional(),
  status: z.enum(['draft', 'upcoming', 'active', 'completed', 'cancelled']),
  requirements: z.array(requirementSchema),
});

type FormValues = z.infer<typeof formSchema>;

const AirdropEdit: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showCalendar, setShowCalendar] = useState<'start' | 'end' | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  
  // Fetch airdrop data
  const { data: airdrop, isLoading: isLoadingAirdrop } = useQuery({
    queryKey: ['admin-airdrop-edit', id],
    queryFn: () => apiRequest<Airdrop>(`/api/admin/airdrops/${id}`),
    enabled: !!id,
  });
  
  // Fetch airdrop tasks
  const { data: tasks, isLoading: isLoadingTasks } = useQuery({
    queryKey: ['admin-airdrop-tasks', id],
    queryFn: () => apiRequest<Task[]>(`/api/admin/airdrops/${id}/tasks`),
    enabled: !!id,
  });
  
  // Set up form with validation
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      tokenSymbol: '',
      tokenAddress: '',
      tokenDecimals: 18,
      totalAmount: '',
      startDate: new Date(),
      status: 'draft',
      requirements: [],
    },
  });
  
  // Set up field array for requirements
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'requirements',
  });
  
  // Update form values when airdrop and tasks data is loaded
  useEffect(() => {
    if (airdrop && tasks) {
      form.reset({
        name: airdrop.name,
        tokenSymbol: airdrop.tokenSymbol,
        tokenAddress: airdrop.tokenAddress,
        tokenDecimals: airdrop.tokenDecimals,
        totalAmount: airdrop.totalAmount,
        startDate: new Date(airdrop.startDate),
        endDate: airdrop.endDate ? new Date(airdrop.endDate) : undefined,
        description: airdrop.description || undefined,
        status: airdrop.status as any,
        requirements: tasks.map(task => ({
          id: task.id,
          type: task.type as any,
          value: task.value,
          description: task.description || undefined,
        })),
      });
    }
  }, [airdrop, tasks, form]);
  
  // Update airdrop mutation
  const updateAirdropMutation = useMutation({
    mutationFn: (data: FormValues) => {
      // Format the data for the API
      const formattedData = {
        ...data,
        startDate: format(data.startDate, 'yyyy-MM-dd'),
        endDate: data.endDate ? format(data.endDate, 'yyyy-MM-dd') : null,
      };
      
      return apiRequest(`/api/admin/airdrops/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formattedData),
      });
    },
    onSuccess: () => {
      toast.success('Airdrop berhasil diperbarui');
      queryClient.invalidateQueries({ queryKey: ['admin-airdrop-edit', id] });
      queryClient.invalidateQueries({ queryKey: ['admin-airdrop-tasks', id] });
      queryClient.invalidateQueries({ queryKey: ['admin-airdrops-list'] });
      
      // Show confirm dialog
      setShowConfirmDialog(true);
    },
    onError: (error) => {
      toast.error('Gagal memperbarui airdrop');
      console.error('Error updating airdrop:', error);
    },
  });
  
  // Handle form submission
  const onSubmit = async (data: FormValues) => {
    try {
      await updateAirdropMutation.mutateAsync(data);
    } catch (error) {
      // Error is handled in the mutation callbacks
    }
  };
  
  const addRequirement = () => {
    append({ type: 'followTwitter', value: '' });
  };
  
  // Helper function to get placeholder text based on requirement type
  const getRequirementPlaceholder = (type: string): string => {
    switch (type) {
      case 'followTwitter':
        return 'Username Twitter (contoh: @example)';
      case 'joinTelegram':
        return 'Link grup Telegram';
      case 'holdTokens':
        return 'Jumlah token minimum yang diperlukan';
      case 'other':
        return 'Deskripsi persyaratan';
      default:
        return 'Masukkan nilai';
    }
  };
  
  // Navigate after dialog confirmation
  const handleConfirmAction = (action: 'dashboard' | 'view' | 'stay') => {
    setShowConfirmDialog(false);
    
    if (action === 'dashboard') {
      navigate('/admin/airdrops');
    } else if (action === 'view') {
      navigate(`/airdrops/${id}`);
    }
  };
  
  // Loading state
  if (isLoadingAirdrop || isLoadingTasks) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-slate-600">Memuat data airdrop...</p>
        </div>
      </div>
    );
  }
  
  // Not found state
  if (!airdrop) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Airdrop Tidak Ditemukan</h2>
          <p className="text-slate-600 mb-4">Airdrop ini mungkin telah dihapus atau tidak ada.</p>
          <Button asChild>
            <Link to="/admin/airdrops">Kembali ke Daftar Airdrop</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Back button and title */}
      <div>
        <Button
          variant="outline"
          size="sm"
          asChild
          className="mb-4"
        >
          <Link to="/admin/airdrops">
            <ChevronLeft className="mr-2 h-4 w-4" /> Kembali ke Daftar Airdrop
          </Link>
        </Button>
        
        <h1 className="text-3xl font-bold">Edit Airdrop: {airdrop.name}</h1>
        <p className="text-slate-600">Perbarui informasi dan parameter airdrop</p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Informasi Dasar</CardTitle>
              <CardDescription>
                Perbarui detail dasar tentang airdrop ini
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Airdrop</FormLabel>
                    <FormControl>
                      <Input placeholder="Masukkan nama airdrop" {...field} />
                    </FormControl>
                    <FormDescription>
                      Nama yang jelas untuk kampanye airdrop Anda
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="tokenSymbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symbol Token</FormLabel>
                      <FormControl>
                        <Input placeholder="contoh: ETH" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="tokenDecimals"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Token Decimals</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="18" 
                          min={0}
                          max={18}
                          {...field}
                          onChange={(e) => {
                            const value = parseInt(e.target.value);
                            field.onChange(isNaN(value) ? 0 : value);
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="tokenAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Alamat Kontrak Token</FormLabel>
                    <FormControl>
                      <Input placeholder="0x..." {...field} />
                    </FormControl>
                    <FormDescription>
                      Alamat kontrak Ethereum dari token
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deskripsi (Opsional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Masukkan deskripsi untuk airdrop Anda"
                        className="resize-none min-h-[120px]" 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih status airdrop" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="upcoming">Mendatang</SelectItem>
                        <SelectItem value="active">Aktif</SelectItem>
                        <SelectItem value="completed">Selesai</SelectItem>
                        <SelectItem value="cancelled">Dibatalkan</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Status saat ini dari airdrop
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Detail Distribusi</CardTitle>
              <CardDescription>
                Konfigurasi bagaimana token Anda akan didistribusikan
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="totalAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Jumlah Token Total</FormLabel>
                    <FormControl>
                      <Input placeholder="contoh: 100000" {...field} />
                    </FormControl>
                    <FormDescription>
                      Jumlah total token yang akan didistribusikan dalam airdrop ini
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Tanggal Mulai</FormLabel>
                      <Popover open={showCalendar === 'start'} onOpenChange={(open) => {
                        if (open) setShowCalendar('start');
                        else setShowCalendar(null);
                      }}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pilih tanggal</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={(date) => {
                              field.onChange(date);
                              setShowCalendar(null);
                            }}
                            disabled={(date) => date < new Date("1900-01-01")}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        Kapan airdrop akan dimulai
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Tanggal Selesai (Opsional)</FormLabel>
                      <Popover open={showCalendar === 'end'} onOpenChange={(open) => {
                        if (open) setShowCalendar('end');
                        else setShowCalendar(null);
                      }}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Tidak ada tanggal selesai</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value || undefined}
                            onSelect={(date) => {
                              field.onChange(date);
                              setShowCalendar(null);
                            }}
                            disabled={(date) => {
                              const startDate = form.getValues('startDate');
                              return date < startDate || date < new Date("1900-01-01");
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        Kapan airdrop akan berakhir (kosongkan untuk tidak ada tanggal akhir)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Persyaratan Kelayakan</CardTitle>
                  <CardDescription>
                    Tentukan kriteria yang harus dipenuhi pengguna untuk memenuhi syarat
                  </CardDescription>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addRequirement}
                  disabled={fields.length >= 5}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Tambah Persyaratan
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {fields.length === 0 && (
                <div className="flex items-center justify-center p-4 border border-dashed rounded-md">
                  <div className="flex flex-col items-center text-center">
                    <AlertCircle className="h-8 w-8 text-slate-400 mb-2" />
                    <p className="text-sm text-slate-600">Tidak ada persyaratan yang ditambahkan</p>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="mt-2"
                      onClick={addRequirement}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Tambah Persyaratan
                    </Button>
                  </div>
                </div>
              )}
              
              {fields.map((field, index) => (
                <div key={field.id} className="flex flex-col space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium">Persyaratan {index + 1}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => remove(index)}
                      className="h-8 w-8 p-0"
                    >
                      <span className="sr-only">Hapus persyaratan</span>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <FormField
                      control={form.control}
                      name={`requirements.${index}.type`}
                      render={({ field }) => (
                        <FormItem>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih tipe" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="followTwitter">Follow Twitter</SelectItem>
                              <SelectItem value="joinTelegram">Join Telegram</SelectItem>
                              <SelectItem value="holdTokens">Hold Tokens</SelectItem>
                              <SelectItem value="other">Lainnya</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="md:col-span-2">
                      <FormField
                        control={form.control}
                        name={`requirements.${index}.value`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input
                                placeholder={getRequirementPlaceholder(form.watch(`requirements.${index}.type`))}
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {index !== fields.length - 1 && (
                    <Separator className="my-2" />
                  )}
                </div>
              ))}
            </CardContent>
            
            <CardFooter className="flex justify-between">
              <Button 
                type="button"
                variant="outline"
                onClick={() => navigate('/admin/airdrops')}
              >
                Batal
              </Button>
              <Button 
                type="submit" 
                disabled={updateAirdropMutation.isPending}
              >
                {updateAirdropMutation.isPending ? 'Menyimpan...' : 'Simpan Perubahan'}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </Form>
      
      {/* Confirmation Dialog after successful update */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Airdrop Berhasil Diperbarui</AlertDialogTitle>
            <AlertDialogDescription>
              Perubahan pada airdrop telah berhasil disimpan. Apa yang ingin Anda lakukan selanjutnya?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => handleConfirmAction('stay')}
            >
              Lanjutkan Mengedit
            </Button>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => handleConfirmAction('view')}
              >
                Lihat Airdrop
              </Button>
              <Button 
                onClick={() => handleConfirmAction('dashboard')}
              >
                Kembali ke Daftar
              </Button>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AirdropEdit;