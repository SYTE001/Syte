import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import { Badge } from '../../components/ui/badge';

import { 
  Plus, 
  Users, 
  CreditCard, 
  Activity, 
  FileText,
  Edit,
  Trash2,
  ExternalLink
} from 'lucide-react';
import StatusBadge from '../../components/airdrop/StatusBadge';
import { formatDate, formatNumber } from '../../lib/utils';

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
  createdAt: string;
}

interface User {
  id: number;
  username: string;
  email: string;
  walletAddress: string;
  createdAt: string;
}

const AdminDashboard: React.FC = () => {
  // Fetch recent airdrops
  const { data: airdrops, isLoading: isLoadingAirdrops } = useQuery({
    queryKey: ['admin-airdrops'],
    queryFn: () => apiRequest<Airdrop[]>('/api/admin/airdrops'),
  });
  
  // Fetch recent users
  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => apiRequest<User[]>('/api/admin/users'),
  });
  
  // Calculate statistics
  const totalUsers = users?.length || 0;
  const totalAirdrops = airdrops?.length || 0;
  const activeAirdrops = airdrops?.filter(a => a.status === 'active').length || 0;
  const totalDistributed = airdrops?.reduce((sum, airdrop) => 
    sum + parseFloat(airdrop.distributedAmount), 0) || 0;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-slate-600">Mengelola airdrops dan pengguna</p>
        </div>
        
        <div className="flex gap-2">
          <Button asChild>
            <Link to="/admin/airdrops/create">
              <Plus className="mr-2 h-4 w-4" /> Buat Airdrop
            </Link>
          </Button>
          
          <Button variant="outline" asChild>
            <Link to="/admin/users">
              <Users className="mr-2 h-4 w-4" /> Kelola Pengguna
            </Link>
          </Button>
        </div>
      </div>
      
      {/* Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-primary/10 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Total Pengguna</p>
                <h3 className="text-2xl font-bold">{totalUsers}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-primary/10 rounded-full">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Total Airdrops</p>
                <h3 className="text-2xl font-bold">{totalAirdrops}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-green-100 rounded-full">
                <Activity className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Airdrops Aktif</p>
                <h3 className="text-2xl font-bold">{activeAirdrops}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-blue-100 rounded-full">
                <CreditCard className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Total Didistribusikan</p>
                <h3 className="text-2xl font-bold">{formatNumber(totalDistributed.toString())}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Airdrops */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Daftar Airdrop</CardTitle>
              <CardDescription>
                Mengelola semua airdrop yang tersedia
              </CardDescription>
            </div>
            
            <Button asChild variant="outline" size="sm">
              <Link to="/admin/airdrops">
                Lihat Semua
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingAirdrops ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-slate-600">Memuat airdrop...</p>
            </div>
          ) : !airdrops || airdrops.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-600 mb-4">Belum ada airdrop yang dibuat.</p>
              <Button asChild>
                <Link to="/admin/airdrops/create">Buat Airdrop</Link>
              </Button>
            </div>
          ) : (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nama</TableHead>
                    <TableHead>Token</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Didistribusikan</TableHead>
                    <TableHead>Tanggal Mulai</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {airdrops.map((airdrop) => (
                    <TableRow key={airdrop.id}>
                      <TableCell className="font-medium">{airdrop.name}</TableCell>
                      <TableCell>{airdrop.tokenSymbol}</TableCell>
                      <TableCell>
                        <StatusBadge status={airdrop.status} />
                      </TableCell>
                      <TableCell>
                        {formatNumber(airdrop.distributedAmount)} / {formatNumber(airdrop.totalAmount)}
                      </TableCell>
                      <TableCell>{formatDate(airdrop.startDate)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center gap-2">
                          <Button variant="ghost" size="icon" asChild>
                            <Link to={`/airdrops/${airdrop.id}`}>
                              <ExternalLink className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="ghost" size="icon" asChild>
                            <Link to={`/admin/airdrops/${airdrop.id}/edit`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="ghost" size="icon" className="text-red-500">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Recent Users */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Pengguna Terbaru</CardTitle>
              <CardDescription>
                Pengguna yang baru bergabung dengan platform
              </CardDescription>
            </div>
            
            <Button asChild variant="outline" size="sm">
              <Link to="/admin/users">
                Lihat Semua
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingUsers ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-slate-600">Memuat pengguna...</p>
            </div>
          ) : !users || users.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-600">Belum ada pengguna yang terdaftar.</p>
            </div>
          ) : (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Wallet Address</TableHead>
                    <TableHead>Tanggal Daftar</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.slice(0, 5).map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {user.walletAddress.substring(0, 6)}...{user.walletAddress.substring(user.walletAddress.length - 4)}
                      </TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;