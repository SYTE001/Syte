import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { toast } from 'sonner';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../components/ui/alert-dialog';
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from '../../components/ui/select';

import { 
  Plus, 
  Search, 
  Filter, 
  SortDesc, 
  SortAsc, 
  ChevronLeft, 
  Edit,
  Trash2,
  ExternalLink,
  Download
} from 'lucide-react';
import StatusBadge from '../../components/airdrop/StatusBadge';
import { formatDate, formatNumber } from '../../lib/utils';

interface Airdrop {
  id: number;
  name: string;
  tokenSymbol: string;
  tokenAddress: string;
  description: string | null;
  totalAmount: string;
  distributedAmount: string;
  startDate: string;
  endDate: string | null;
  status: string;
  createdAt: string;
  createdBy: number;
}

type SortField = 'name' | 'totalAmount' | 'startDate' | 'status';
type SortDirection = 'asc' | 'desc';

const AirdropManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('startDate');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedAirdropId, setSelectedAirdropId] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const queryClient = useQueryClient();
  
  // Fetch all airdrops for admin
  const { data: airdrops, isLoading } = useQuery({
    queryKey: ['admin-airdrops-list'],
    queryFn: () => apiRequest<Airdrop[]>('/api/admin/airdrops'),
  });
  
  // Delete airdrop mutation
  const deleteAirdropMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/airdrops/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast.success('Airdrop berhasil dihapus');
      queryClient.invalidateQueries({ queryKey: ['admin-airdrops-list'] });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast.error('Gagal menghapus airdrop');
      console.error('Error deleting airdrop:', error);
    },
  });
  
  const handleDeleteClick = (id: number) => {
    setSelectedAirdropId(id);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (selectedAirdropId) {
      deleteAirdropMutation.mutate(selectedAirdropId);
    }
  };
  
  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  // Filter and sort airdrops
  const filteredAirdrops = airdrops ? airdrops
    .filter(airdrop => {
      const matchesSearch = !searchTerm || 
        airdrop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        airdrop.tokenSymbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (airdrop.description && airdrop.description.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesStatus = !statusFilter || airdrop.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let valueA, valueB;
      
      if (sortField === 'name') {
        valueA = a.name.toLowerCase();
        valueB = b.name.toLowerCase();
      } else if (sortField === 'totalAmount') {
        valueA = parseFloat(a.totalAmount);
        valueB = parseFloat(b.totalAmount);
      } else if (sortField === 'status') {
        valueA = a.status;
        valueB = b.status;
      } else {
        valueA = new Date(a.startDate).getTime();
        valueB = new Date(b.startDate).getTime();
      }
      
      return sortDirection === 'asc' 
        ? (valueA > valueB ? 1 : -1) 
        : (valueA < valueB ? 1 : -1);
    }) : [];
  
  // Function to export airdrops data as CSV
  const exportToCSV = () => {
    if (!airdrops || airdrops.length === 0) {
      toast.error('Tidak ada data untuk diekspor');
      return;
    }
    
    // Define the CSV headers
    const headers = [
      'ID',
      'Nama',
      'Token Symbol',
      'Token Address',
      'Jumlah Total',
      'Jumlah Didistribusikan',
      'Tanggal Mulai',
      'Tanggal Selesai',
      'Status',
      'Tanggal Dibuat'
    ].join(',');
    
    // Create CSV rows
    const rows = airdrops.map(airdrop => [
      airdrop.id,
      `"${airdrop.name.replace(/"/g, '""')}"`, // Escape quotes in name
      airdrop.tokenSymbol,
      airdrop.tokenAddress,
      airdrop.totalAmount,
      airdrop.distributedAmount,
      airdrop.startDate,
      airdrop.endDate || '',
      airdrop.status,
      airdrop.createdAt
    ].join(','));
    
    // Combine headers and rows
    const csvContent = [headers, ...rows].join('\n');
    
    // Create a blob and download the file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `airdrops_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Data airdrop berhasil diekspor ke CSV');
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
          <Button
            variant="outline"
            size="sm"
            asChild
            className="mb-4"
          >
            <Link to="/admin">
              <ChevronLeft className="mr-2 h-4 w-4" /> Kembali ke Dashboard
            </Link>
          </Button>
          
          <h1 className="text-3xl font-bold">Manajemen Airdrop</h1>
          <p className="text-slate-600">Mengelola semua airdrop di platform</p>
        </div>
        
        <div className="flex gap-2">
          <Button onClick={exportToCSV}>
            <Download className="mr-2 h-4 w-4" /> Ekspor CSV
          </Button>
          
          <Button asChild>
            <Link to="/admin/airdrops/create">
              <Plus className="mr-2 h-4 w-4" /> Buat Airdrop
            </Link>
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Semua Airdrop</CardTitle>
          <CardDescription>
            Kelola airdrop atau tambahkan yang baru
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <Input
                placeholder="Cari airdrop..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2">
              <div className="w-40">
                <Select value={statusFilter || ''} onValueChange={(value) => setStatusFilter(value || null)}>
                  <SelectTrigger>
                    <div className="flex items-center">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Status" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Filter berdasarkan Status</SelectLabel>
                      <SelectItem value="">Semua</SelectItem>
                      <SelectItem value="active">Aktif</SelectItem>
                      <SelectItem value="upcoming">Mendatang</SelectItem>
                      <SelectItem value="completed">Selesai</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-48">
                <Select value={sortField} onValueChange={(value) => setSortField(value as SortField)}>
                  <SelectTrigger>
                    <div className="flex items-center">
                      {sortDirection === 'asc' ? (
                        <SortAsc className="mr-2 h-4 w-4" />
                      ) : (
                        <SortDesc className="mr-2 h-4 w-4" />
                      )}
                      <SelectValue placeholder="Urut berdasarkan" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Urut berdasarkan</SelectLabel>
                      <SelectItem value="name">Nama</SelectItem>
                      <SelectItem value="totalAmount">Jumlah</SelectItem>
                      <SelectItem value="startDate">Tanggal</SelectItem>
                      <SelectItem value="status">Status</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <Button variant="outline" size="icon" onClick={toggleSortDirection}>
                {sortDirection === 'asc' ? (
                  <SortAsc className="h-4 w-4" />
                ) : (
                  <SortDesc className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-slate-600">Memuat airdrop...</p>
            </div>
          ) : filteredAirdrops.length > 0 ? (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead>Token</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Didistribusikan</TableHead>
                    <TableHead>Tanggal Mulai</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAirdrops.map((airdrop) => (
                    <TableRow key={airdrop.id}>
                      <TableCell>{airdrop.id}</TableCell>
                      <TableCell className="font-medium">{airdrop.name}</TableCell>
                      <TableCell>{airdrop.tokenSymbol}</TableCell>
                      <TableCell>
                        <StatusBadge status={airdrop.status} />
                      </TableCell>
                      <TableCell>{formatNumber(airdrop.totalAmount)}</TableCell>
                      <TableCell>{formatNumber(airdrop.distributedAmount)}</TableCell>
                      <TableCell>{formatDate(airdrop.startDate)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center gap-1">
                          <Button variant="ghost" size="icon" asChild>
                            <Link to={`/airdrops/${airdrop.id}`}>
                              <ExternalLink className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="ghost" size="icon" asChild>
                            <Link to={`/admin/airdrops/${airdrop.id}/edit`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-red-500"
                            onClick={() => handleDeleteClick(airdrop.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              {searchTerm || statusFilter ? (
                <p className="text-slate-600">Tidak ada airdrop yang ditemukan dengan filter saat ini.</p>
              ) : (
                <p className="text-slate-600">Belum ada airdrop yang tersedia.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin ingin menghapus airdrop ini?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Ini akan secara permanen menghapus airdrop
              dan semua data terkait termasuk peserta dan alokasi.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {deleteAirdropMutation.isPending ? 'Menghapus...' : 'Hapus Airdrop'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AirdropManagement;