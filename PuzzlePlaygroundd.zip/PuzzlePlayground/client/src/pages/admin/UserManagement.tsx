import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../../lib/queryClient';
import { toast } from 'sonner';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../components/ui/table';
import { Badge } from '../../components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '../../components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '../../components/ui/form';
import { Switch } from '../../components/ui/switch';

import { 
  ChevronLeft, 
  Search, 
  Filter, 
  UserPlus, 
  SortDesc, 
  SortAsc, 
  Edit, 
  UserCog, 
  Trash2, 
  Mail, 
  Wallet, 
  ShieldCheck, 
  Shield 
} from 'lucide-react';
import { formatDate, truncateAddress } from '../../lib/utils';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

interface User {
  id: number;
  username: string;
  email: string;
  walletAddress: string;
  role: string;
  createdAt: string;
}

type SortField = 'id' | 'username' | 'email' | 'createdAt';
type SortDirection = 'asc' | 'desc';

// Form schema untuk edit user
const userEditSchema = z.object({
  username: z.string().min(3, "Username minimal 3 karakter"),
  email: z.string().email("Email tidak valid"),
  walletAddress: z.string().min(42, "Alamat wallet tidak valid"),
  role: z.enum(["user", "admin"]).default("user"),
});

type UserEditFormValues = z.infer<typeof userEditSchema>;

const UserManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  
  const queryClient = useQueryClient();
  
  // Fetch all users
  const { data: users, isLoading } = useQuery({
    queryKey: ['admin-users-list'],
    queryFn: () => apiRequest<User[]>('/api/admin/users'),
  });
  
  // Fetch individual user for editing
  const { data: selectedUser } = useQuery({
    queryKey: ['admin-user-edit', selectedUserId],
    queryFn: () => apiRequest<User>(`/api/admin/users/${selectedUserId}`),
    enabled: !!selectedUserId && isEditDialogOpen,
  });
  
  // Form setup for editing user
  const form = useForm<UserEditFormValues>({
    resolver: zodResolver(userEditSchema),
    defaultValues: {
      username: '',
      email: '',
      walletAddress: '',
      role: 'user',
    },
  });
  
  // Update form values when selected user changes
  React.useEffect(() => {
    if (selectedUser) {
      form.reset({
        username: selectedUser.username,
        email: selectedUser.email,
        walletAddress: selectedUser.walletAddress,
        role: selectedUser.role,
      });
    }
  }, [selectedUser, form]);
  
  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: (data: UserEditFormValues) => 
      apiRequest(`/api/admin/users/${selectedUserId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      toast.success('Pengguna berhasil diperbarui');
      setIsEditDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['admin-users-list'] });
    },
    onError: (error) => {
      toast.error('Gagal memperbarui pengguna');
      console.error('Error updating user:', error);
    },
  });
  
  // Make admin mutation
  const toggleAdminMutation = useMutation({
    mutationFn: (userId: number) => 
      apiRequest(`/api/admin/users/${userId}/toggle-admin`, {
        method: 'PUT',
      }),
    onSuccess: () => {
      toast.success('Status admin berhasil diubah');
      queryClient.invalidateQueries({ queryKey: ['admin-users-list'] });
    },
    onError: (error) => {
      toast.error('Gagal mengubah status admin');
      console.error('Error toggling admin status:', error);
    },
  });
  
  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/users/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast.success('Pengguna berhasil dihapus');
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['admin-users-list'] });
    },
    onError: (error) => {
      toast.error('Gagal menghapus pengguna');
      console.error('Error deleting user:', error);
    },
  });
  
  const handleDeleteClick = (id: number) => {
    setSelectedUserId(id);
    setIsDeleteDialogOpen(true);
  };
  
  const handleEditClick = (id: number) => {
    setSelectedUserId(id);
    setIsEditDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (selectedUserId) {
      deleteUserMutation.mutate(selectedUserId);
    }
  };
  
  const handleToggleAdmin = (id: number) => {
    toggleAdminMutation.mutate(id);
  };
  
  const toggleSortDirection = () => {
    setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  // Submit edit form
  const onSubmit = (data: UserEditFormValues) => {
    updateUserMutation.mutate(data);
  };
  
  // Filter and sort users
  const filteredUsers = users ? users
    .filter(user => {
      const matchesSearch = !searchTerm || 
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.walletAddress.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesRole = !roleFilter || 
        (roleFilter === 'admin' && user.role === 'admin') ||
        (roleFilter === 'user' && user.role === 'user');
      
      return matchesSearch && matchesRole;
    })
    .sort((a, b) => {
      let valueA, valueB;
      
      if (sortField === 'id') {
        valueA = a.id;
        valueB = b.id;
      } else if (sortField === 'username') {
        valueA = a.username.toLowerCase();
        valueB = b.username.toLowerCase();
      } else if (sortField === 'email') {
        valueA = a.email.toLowerCase();
        valueB = b.email.toLowerCase();
      } else {
        valueA = new Date(a.createdAt).getTime();
        valueB = new Date(b.createdAt).getTime();
      }
      
      return sortDirection === 'asc' 
        ? (valueA > valueB ? 1 : -1) 
        : (valueA < valueB ? 1 : -1);
    }) : [];
  
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
          <Button
            variant="outline"
            size="sm"
            asChild
            className="mb-4"
          >
            <Link to="/admin">
              <ChevronLeft className="mr-2 h-4 w-4" /> Kembali ke Dashboard
            </Link>
          </Button>
          
          <h1 className="text-3xl font-bold">Manajemen Pengguna</h1>
          <p className="text-slate-600">Kelola semua pengguna di platform</p>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Semua Pengguna</CardTitle>
          <CardDescription>
            Daftar semua pengguna yang terdaftar di platform
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <Input
                placeholder="Cari username, email, atau alamat wallet..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2">
              <div className="w-40">
                <Select value={roleFilter || ''} onValueChange={(value) => setRoleFilter(value || null)}>
                  <SelectTrigger>
                    <div className="flex items-center">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Role" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Semua</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="user">Pengguna</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-40">
                <Select value={sortField} onValueChange={(value) => setSortField(value as SortField)}>
                  <SelectTrigger>
                    <div className="flex items-center">
                      {sortDirection === 'asc' ? (
                        <SortAsc className="mr-2 h-4 w-4" />
                      ) : (
                        <SortDesc className="mr-2 h-4 w-4" />
                      )}
                      <SelectValue placeholder="Urut" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="id">ID</SelectItem>
                    <SelectItem value="username">Username</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="createdAt">Tanggal Daftar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button variant="outline" size="icon" onClick={toggleSortDirection}>
                {sortDirection === 'asc' ? (
                  <SortAsc className="h-4 w-4" />
                ) : (
                  <SortDesc className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-slate-600">Memuat pengguna...</p>
            </div>
          ) : filteredUsers.length > 0 ? (
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Username</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Wallet Address</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Tanggal Daftar</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.id}</TableCell>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {truncateAddress(user.walletAddress)}
                      </TableCell>
                      <TableCell>
                        {user.role === 'admin' ? (
                          <Badge className="bg-purple-100 text-purple-800 dark:bg-purple-800 dark:text-purple-100">
                            <ShieldCheck className="h-3 w-3 mr-1" /> Admin
                          </Badge>
                        ) : (
                          <Badge variant="outline">Pengguna</Badge>
                        )}
                      </TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleToggleAdmin(user.id)}
                            title={user.role === 'admin' ? "Hapus hak admin" : "Jadikan admin"}
                          >
                            {user.role === 'admin' ? (
                              <Shield className="h-4 w-4 text-purple-500" />
                            ) : (
                              <ShieldCheck className="h-4 w-4" />
                            )}
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEditClick(user.id)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-red-500"
                            onClick={() => handleDeleteClick(user.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-600">
                {searchTerm || roleFilter ? (
                  'Tidak ada pengguna yang ditemukan dengan filter saat ini.'
                ) : (
                  'Belum ada pengguna yang terdaftar.'
                )}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apakah Anda yakin ingin menghapus pengguna ini?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Pengguna akan dihapus secara permanen beserta semua data terkait.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {deleteUserMutation.isPending ? 'Menghapus...' : 'Hapus Pengguna'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Pengguna</DialogTitle>
            <DialogDescription>
              Perbarui informasi pengguna. Klik simpan saat selesai.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <div className="flex items-center">
                        <UserCog className="h-4 w-4 text-slate-500 mr-2" />
                        <Input placeholder="Username" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 text-slate-500 mr-2" />
                        <Input placeholder="Email" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="walletAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Wallet Address</FormLabel>
                    <FormControl>
                      <div className="flex items-center">
                        <Wallet className="h-4 w-4 text-slate-500 mr-2" />
                        <Input placeholder="0x..." {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between p-3 rounded-lg border">
                    <div className="space-y-0.5">
                      <FormLabel>Status Admin</FormLabel>
                      <FormDescription>
                        Tetapkan pengguna ini sebagai administrator
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value === 'admin'}
                        onCheckedChange={(checked) => field.onChange(checked ? 'admin' : 'user')}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit" disabled={updateUserMutation.isPending}>
                  {updateUserMutation.isPending ? 'Menyimpan...' : 'Simpan Perubahan'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserManagement;