import React, { useEffect } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../lib/contexts/AuthContext';
import { Gift } from 'lucide-react';

const AuthLayout: React.FC = () => {
  const { user, loading } = useAuth();
  
  // Redirect to dashboard if already authenticated
  if (!loading && user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="mb-8 flex flex-col items-center">
          <Gift className="h-12 w-12 text-slate-800 mb-2" />
          <h1 className="text-2xl font-bold text-slate-800">CryptoAirdropManager</h1>
          <p className="text-slate-600">Manage your crypto airdrops in one place</p>
        </div>
        
        <div className="w-full max-w-md bg-white rounded-lg shadow-md p-8">
          <Outlet />
        </div>
      </div>
      
      <footer className="bg-slate-800 text-white px-6 py-4 text-center text-sm">
        <div className="container mx-auto">
          <p>&copy; {new Date().getFullYear()} Crypto Airdrop Manager. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default AuthLayout;