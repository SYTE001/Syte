import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/contexts/AuthContext';
import { Button } from '../components/ui/button';
import { 
  User, 
  LogOut, 
  Home, 
  Gift, 
  Users, 
  User as UserIcon, 
  ShieldCheck, 
  LayoutDashboard,
  Settings
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-slate-800 text-white px-6 py-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-1">
            <Gift className="h-6 w-6 mr-2" />
            <h1 className="text-xl font-bold">CryptoAirdropManager</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <div className="hidden md:flex items-center">
                  <span className="mr-2">Welcome, {user.username}</span>
                  {user.role === 'admin' && (
                    <span className="bg-purple-600 text-white text-xs px-2 py-0.5 rounded-md flex items-center">
                      <ShieldCheck className="h-3 w-3 mr-1" />
                      Admin
                    </span>
                  )}
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleLogout}
                  className="text-white hover:text-white hover:bg-slate-700"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  <span>Logout</span>
                </Button>
              </>
            ) : (
              <>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  asChild
                  className="text-white hover:text-white hover:bg-slate-700"
                >
                  <Link to="/login">Login</Link>
                </Button>
                <Button 
                  variant="default" 
                  size="sm" 
                  asChild
                >
                  <Link to="/register">Register</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {user && (
          <nav className="w-64 bg-slate-100 p-6 flex-shrink-0 hidden md:block">
            <div className="space-y-1">
              <Button 
                variant="ghost" 
                size="sm" 
                asChild
                className="w-full justify-start"
              >
                <Link to="/">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Link>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                asChild
                className="w-full justify-start"
              >
                <Link to="/airdrops">
                  <Gift className="h-4 w-4 mr-2" />
                  All Airdrops
                </Link>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                asChild
                className="w-full justify-start"
              >
                <Link to="/airdrops/create">
                  <Gift className="h-4 w-4 mr-2" />
                  Create Airdrop
                </Link>
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                asChild
                className="w-full justify-start"
              >
                <Link to="/profile">
                  <UserIcon className="h-4 w-4 mr-2" />
                  Profil Saya
                </Link>
              </Button>
              
              {user.role === 'admin' && (
                <>
                  <div className="pt-4 pb-2">
                    <p className="px-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Admin Menu
                    </p>
                    <div className="h-px bg-slate-200 my-2"></div>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    asChild
                    className="w-full justify-start"
                  >
                    <Link to="/admin">
                      <LayoutDashboard className="h-4 w-4 mr-2" />
                      Dashboard Admin
                    </Link>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    asChild
                    className="w-full justify-start"
                  >
                    <Link to="/admin/airdrops">
                      <Gift className="h-4 w-4 mr-2" />
                      Kelola Airdrop
                    </Link>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    asChild
                    className="w-full justify-start"
                  >
                    <Link to="/admin/users">
                      <Users className="h-4 w-4 mr-2" />
                      Kelola Pengguna
                    </Link>
                  </Button>
                </>
              )}
            </div>
          </nav>
        )}
        
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
      
      <footer className="bg-slate-800 text-white px-6 py-4 text-center text-sm">
        <div className="container mx-auto">
          <p>&copy; {new Date().getFullYear()} Crypto Airdrop Manager. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default MainLayout;