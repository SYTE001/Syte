import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import StatusBadge from './StatusBadge';
import { formatDate, formatNumber } from '../../lib/utils';
import { Calendar, Coins, ExternalLink } from 'lucide-react';

interface AirdropCardProps {
  airdrop: {
    id: number;
    name: string;
    tokenSymbol: string;
    description?: string;
    totalAmount: string;
    distributedAmount: string;
    startDate: string;
    endDate: string | null;
    status: string;
  };
}

const AirdropCard: React.FC<AirdropCardProps> = ({ airdrop }) => {
  // Calculate distribution percentage
  const totalAmount = parseFloat(airdrop.totalAmount);
  const distributedAmount = parseFloat(airdrop.distributedAmount);
  const distributionPercentage = totalAmount > 0 
    ? Math.min(Math.round((distributedAmount / totalAmount) * 100), 100)
    : 0;
  
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="line-clamp-1">{airdrop.name}</CardTitle>
          <StatusBadge status={airdrop.status} />
        </div>
        <CardDescription className="flex items-center">
          <Coins className="h-4 w-4 mr-1 inline" />
          {airdrop.tokenSymbol} - {formatNumber(airdrop.totalAmount)}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pb-2 flex-grow">
        {airdrop.description && (
          <p className="text-sm text-slate-600 mb-4 line-clamp-3">{airdrop.description}</p>
        )}
        
        <div className="text-sm space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-slate-500 flex items-center">
              <Calendar className="h-3.5 w-3.5 mr-1" />
              Start Date:
            </span>
            <span>{formatDate(airdrop.startDate)}</span>
          </div>
          
          {airdrop.endDate && (
            <div className="flex justify-between items-center">
              <span className="text-slate-500 flex items-center">
                <Calendar className="h-3.5 w-3.5 mr-1" />
                End Date:
              </span>
              <span>{formatDate(airdrop.endDate)}</span>
            </div>
          )}
          
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-slate-500 text-xs">Distribution Progress</span>
              <span className="text-xs font-medium">{distributionPercentage}%</span>
            </div>
            <Progress value={distributionPercentage} className="h-2" />
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="pt-2">
        <Button variant="outline" className="w-full" asChild>
          <Link to={`/airdrops/${airdrop.id}`}>
            <ExternalLink className="mr-2 h-4 w-4" /> View Details
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default AirdropCard;