import React from 'react';
import { Badge } from '../ui/badge';
import { getStatusColor } from '../../lib/utils';

interface StatusBadgeProps {
  status: string;
  className?: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  return (
    <Badge 
      variant="outline" 
      className={`${getStatusColor(status)} ${className}`}
    >
      {status}
    </Badge>
  );
};

export default StatusBadge;