import { DifficultyLevel, PlayerProgress } from "@/types/gameTypes";

// Difficulty settings for different levels
interface DifficultySettings {
  timeLimit: number;
  itemCount: number;
  complexity: number;
}

// Default difficulty settings for each level
const difficultyPresets: Record<DifficultyLevel, DifficultySettings> = {
  easy: {
    timeLimit: 120, // seconds
    itemCount: 6,
    complexity: 1
  },
  medium: {
    timeLimit: 90,
    itemCount: 10,
    complexity: 2
  },
  hard: {
    timeLimit: 60,
    itemCount: 15,
    complexity: 3
  },
  adaptive: {
    timeLimit: 100, // baseline, will be adjusted
    itemCount: 8, // baseline, will be adjusted
    complexity: 2 // baseline, will be adjusted
  }
};

// Calculate adaptive difficulty based on player performance
export function calculateAdaptiveDifficulty(
  playerProgress: PlayerProgress
): DifficultySettings {
  const { performance } = playerProgress;
  
  // Calculate success rate (avoid division by zero)
  const totalAttempts = performance.correctAnswers + performance.incorrectAnswers;
  const successRate = totalAttempts === 0 
    ? 0.5 // default to medium if no attempts
    : performance.correctAnswers / totalAttempts;
  
  // Calculate average time per puzzle (if any puzzles completed)
  const avgTimePerPuzzle = playerProgress.puzzlesCompleted === 0
    ? 90 // default to medium time if no puzzles completed
    : performance.timeSpent / playerProgress.puzzlesCompleted;
  
  // Calculate streak factor (higher streak means higher skill)
  const streakFactor = performance.longestStreak / 10; // normalize to 0-1 range
  
  // Calculate difficulty level (0-1 scale)
  let difficultyScore = 0.5; // start at medium
  
  // Adjust based on success rate (higher success = higher difficulty)
  difficultyScore += (successRate - 0.5) * 0.5;
  
  // Adjust based on time (faster completion = higher difficulty)
  const timeBonus = Math.max(0, Math.min(0.3, (90 - avgTimePerPuzzle) / 200));
  difficultyScore += timeBonus;
  
  // Adjust based on streak (higher streak = higher difficulty)
  difficultyScore += streakFactor * 0.2;
  
  // Clamp the difficulty between 0 and 1
  difficultyScore = Math.max(0, Math.min(1, difficultyScore));
  
  console.log(`Adaptive difficulty score: ${difficultyScore.toFixed(2)}`);
  
  // Map the 0-1 difficulty score to actual settings
  return {
    timeLimit: Math.round(
      difficultyPresets.easy.timeLimit - 
      (difficultyPresets.easy.timeLimit - difficultyPresets.hard.timeLimit) * difficultyScore
    ),
    itemCount: Math.round(
      difficultyPresets.easy.itemCount + 
      (difficultyPresets.hard.itemCount - difficultyPresets.easy.itemCount) * difficultyScore
    ),
    complexity: Math.round(
      difficultyPresets.easy.complexity + 
      (difficultyPresets.hard.complexity - difficultyPresets.easy.complexity) * difficultyScore
    )
  };
}

// Get appropriate difficulty settings based on selected difficulty level
export function getDifficultySettings(
  selectedDifficulty: DifficultyLevel,
  playerProgress: PlayerProgress
): DifficultySettings {
  // If adaptive, calculate based on performance
  if (selectedDifficulty === "adaptive") {
    return calculateAdaptiveDifficulty(playerProgress);
  }
  
  // Otherwise return the preset
  return difficultyPresets[selectedDifficulty];
}
