import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const getLocalStorage = (key: string): any =>
  JSON.parse(window.localStorage.getItem(key) || "null");
  
const setLocalStorage = (key: string, value: any): void =>
  window.localStorage.setItem(key, JSON.stringify(value));

/**
 * Format a date to a readable string
 */
export function formatDate(date: Date | string | null, includeTime: boolean = false): string {
  if (!date) return 'N/A';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  const options: Intl.DateTimeFormatOptions = {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    ...(includeTime ? { hour: '2-digit', minute: '2-digit' } : {})
  };
  
  return new Intl.DateTimeFormat('id-ID', options).format(dateObj);
}

/**
 * Format a number to a string with commas as thousands separators
 */
export function formatNumber(num: number | string): string {
  if (typeof num === 'string') {
    num = parseFloat(num);
  }
  
  return num.toLocaleString('id-ID');
}

/**
 * Truncate an Ethereum address for display
 */
export function truncateAddress(address: string): string {
  if (!address) return '';
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}

/**
 * Get initials from a name
 */
export function getInitials(name: string): string {
  if (!name) return '';
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase();
}

/**
 * Get color class for airdrop status
 */
export function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'active':
    case 'eligible':
    case 'claimed':
    case 'approved':
      return 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100';
    
    case 'draft':
    case 'pending':
    case 'upcoming':
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100';
    
    case 'completed':
    case 'distributed':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100';
    
    case 'cancelled':
    case 'rejected':
    case 'ineligible':
    case 'failed':
      return 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100';
    
    case 'unclaimed':
    case 'waiting':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-800 dark:text-purple-100';
    
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100';
  }
}

/**
 * Get text for airdrop status
 */
export function getStatusText(status: string): string {
  switch (status) {
    case 'active':
      return 'Aktif';
    case 'draft':
      return 'Draft';
    case 'completed':
      return 'Selesai';
    case 'cancelled':
      return 'Dibatalkan';
    default:
      return status;
  }
}

export { getLocalStorage, setLocalStorage };
