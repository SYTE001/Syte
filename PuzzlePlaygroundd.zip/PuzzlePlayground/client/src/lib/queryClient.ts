import { QueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    let errorData;
    try {
      errorData = await res.json();
    } catch (e) {
      errorData = { message: res.statusText || 'Terjadi kesalahan' };
    }
    
    const error = new Error(errorData.message || 'Terjadi kesalahan');
    throw error;
  }
  
  return res;
}

export async function apiRequest<T = any>(
  url: string,
  options: RequestInit & { on401?: 'returnNull' | 'throw' } = {}
): Promise<T> {
  const { on401 = 'throw', ...fetchOptions } = options;
  
  try {
    const res = await fetch(url, {
      ...fetchOptions,
      credentials: 'include',
    });
    
    if (res.status === 401 && on401 === 'returnNull') {
      return null as T;
    }
    
    await throwIfResNotOk(res);
    
    // Return null for 204 No Content
    if (res.status === 204) {
      return null as T;
    }
    
    return await res.json();
  } catch (error: any) {
    console.error('API request error:', error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";

export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => (url: string) => Promise<T> = (options) => {
  return (url) => apiRequest<T>(url, options);
};

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes
      onError: (error) => {
        toast.error(
          error instanceof Error ? error.message : 'Terjadi kesalahan'
        );
      },
    },
    mutations: {
      onError: (error) => {
        toast.error(
          error instanceof Error ? error.message : 'Terjadi kesalahan'
        );
      },
    },
  },
});