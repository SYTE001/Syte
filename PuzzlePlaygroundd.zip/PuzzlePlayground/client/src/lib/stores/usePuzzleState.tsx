import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { getLocalStorage, setLocalStorage } from "@/lib/utils";
import { 
  GameState, 
  GamePhase, 
  PuzzleType, 
  DifficultyLevel,
  PlayerProgress,
  GameSettings
} from "@/types/gameTypes";

// Initial player progress
const initialProgress: PlayerProgress = {
  level: 1,
  score: 0,
  stars: 0,
  puzzlesCompleted: 0,
  difficultyLevel: "adaptive",
  performance: {
    correctAnswers: 0,
    incorrectAnswers: 0,
    timeSpent: 0,
    currentStreak: 0,
    longestStreak: 0
  }
};

// Initial game settings
const initialSettings: GameSettings = {
  volume: 0.7,
  musicEnabled: true,
  soundEffectsEnabled: true,
  difficulty: "adaptive",
  parentalControlsEnabled: false
};

// Initial game state
const initialGameState: GameState = {
  phase: "menu",
  currentPuzzle: null,
  playerProgress: initialProgress,
  settings: initialSettings
};

// Create context for game state
type GameContextType = {
  gameState: GameState;
  startPuzzle: (puzzleType: PuzzleType) => void;
  completePuzzle: (success: boolean, score: number, timeSpent: number) => void;
  pauseGame: () => void;
  resumeGame: () => void;
  returnToMenu: () => void;
  updateSettings: (settings: Partial<GameSettings>) => void;
  resetProgress: () => void;
};

const GameContext = createContext<GameContextType | undefined>(undefined);

// Provider component
export const GameProvider = ({ children }: { children: ReactNode }) => {
  // Load saved state from localStorage or use initial state
  const [gameState, setGameState] = useState<GameState>(() => {
    const savedState = getLocalStorage("puzzleGameState");
    return savedState || initialGameState;
  });

  // Save state to localStorage when it changes
  useEffect(() => {
    setLocalStorage("puzzleGameState", gameState);
  }, [gameState]);

  // Start a puzzle
  const startPuzzle = (puzzleType: PuzzleType) => {
    console.log(`Starting puzzle: ${puzzleType}`);
    setGameState({
      ...gameState,
      phase: "playing",
      currentPuzzle: puzzleType
    });
  };

  // Complete a puzzle and update player progress
  const completePuzzle = (success: boolean, score: number, timeSpent: number) => {
    const { playerProgress } = gameState;
    
    // Update progress based on performance
    const newProgress = {
      ...playerProgress,
      score: playerProgress.score + score,
      puzzlesCompleted: playerProgress.puzzlesCompleted + 1,
      performance: {
        ...playerProgress.performance,
        correctAnswers: success 
          ? playerProgress.performance.correctAnswers + 1 
          : playerProgress.performance.correctAnswers,
        incorrectAnswers: !success 
          ? playerProgress.performance.incorrectAnswers + 1 
          : playerProgress.performance.incorrectAnswers,
        timeSpent: playerProgress.performance.timeSpent + timeSpent,
        currentStreak: success 
          ? playerProgress.performance.currentStreak + 1 
          : 0,
        longestStreak: success 
          ? Math.max(playerProgress.performance.longestStreak, playerProgress.performance.currentStreak + 1) 
          : playerProgress.performance.longestStreak
      }
    };

    // Level up every 3 completed puzzles
    if (newProgress.puzzlesCompleted % 3 === 0) {
      newProgress.level += 1;
      newProgress.stars += 1;
    }

    console.log(`Puzzle completed. Success: ${success}, Score: ${score}`);
    
    setGameState({
      ...gameState,
      phase: "complete",
      playerProgress: newProgress
    });
  };

  // Pause the game
  const pauseGame = () => {
    if (gameState.phase === "playing") {
      setGameState({
        ...gameState,
        phase: "paused"
      });
    }
  };

  // Resume the game from pause
  const resumeGame = () => {
    if (gameState.phase === "paused") {
      setGameState({
        ...gameState,
        phase: "playing"
      });
    }
  };

  // Return to the main menu
  const returnToMenu = () => {
    setGameState({
      ...gameState,
      phase: "menu",
      currentPuzzle: null
    });
  };

  // Update game settings
  const updateSettings = (settings: Partial<GameSettings>) => {
    setGameState({
      ...gameState,
      settings: {
        ...gameState.settings,
        ...settings
      }
    });
  };

  // Reset progress (parental control)
  const resetProgress = () => {
    setGameState({
      ...gameState,
      playerProgress: initialProgress
    });
  };

  // Context provider value
  const value = {
    gameState,
    startPuzzle,
    completePuzzle,
    pauseGame,
    resumeGame,
    returnToMenu,
    updateSettings,
    resetProgress
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
};

// Custom hook for using the game context
export const usePuzzleState = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error("usePuzzleState must be used within a GameProvider");
  }
  return context;
};
