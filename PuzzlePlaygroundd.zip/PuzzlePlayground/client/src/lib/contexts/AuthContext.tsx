import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from '../queryClient';
import { toast } from 'sonner';

interface User {
  id: number;
  username: string;
  email: string;
  walletAddress: string;
  role: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (credentials: { username: string; password: string }) => Promise<void>;
  register: (data: {
    username: string;
    email: string;
    password: string;
    walletAddress: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch the current user on initial load
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const userData = await apiRequest<User | null>('/api/auth/me', { on401: 'returnNull' });
        setUser(userData);
      } catch (err) {
        console.error('Error fetching current user:', err);
        setError('Failed to fetch user data');
      } finally {
        setLoading(false);
      }
    };

    fetchCurrentUser();
  }, []);

  // Login function
  const login = async (credentials: { username: string; password: string }) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest<User>('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });
      
      setUser(response);
      toast.success('Logged in successfully');
    } catch (err) {
      const error = err as Error;
      console.error('Login error:', error);
      setError(error.message || 'Failed to log in');
      toast.error('Login failed. Please check your credentials.');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Register function
  const register = async (data: {
    username: string;
    email: string;
    password: string;
    walletAddress: string;
  }) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest<User>('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      setUser(response);
      toast.success('Registered successfully');
    } catch (err) {
      const error = err as Error;
      console.error('Registration error:', error);
      setError(error.message || 'Failed to register');
      toast.error('Registration failed. Please try again.');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setLoading(true);
    
    try {
      await apiRequest('/api/auth/logout', {
        method: 'POST',
      });
      
      setUser(null);
      toast.success('Logged out successfully');
    } catch (err) {
      console.error('Logout error:', err);
      toast.error('Failed to log out');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};